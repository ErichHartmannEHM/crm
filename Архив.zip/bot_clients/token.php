<?php
$tg_clients_token = '7882934966:AAGdoV2fJc1dv3AWKZNCPePVHIALoa9aPEA';
