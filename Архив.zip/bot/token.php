<?php
// /bot_clients/token.php — токен отдельного бота для рассылок «Клиенты».
// ХРАНИТЕ ФАЙЛ ВНЕ GIT/РЕПО И ЗАКРОЙТЕ ДОСТУП ИЗ ВНЕШНЕГО МИРА!
// Альтернатива: запишите токен в settings.key = 'clients.bot_token'
// или переменную окружения TG_CLIENT_BOT_TOKEN.
if (!defined('CLIENTS_BOT_TOKEN')) {
  define('CLIENTS_BOT_TOKEN', '7882934966:AAGdoV2fJc1dv3AWKZNCPePVHIALoa9aPEA');
}
