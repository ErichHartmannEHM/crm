<?php
declare(strict_types=1);

require_once __DIR__.'/db.php';
require_once __DIR__.'/helpers.php';
@require_once __DIR__.'/settings.php';

/* ------- Полифилы DB (если не объявлены глобально) ------- */
if (!function_exists('db_cell')) {
  function db_cell(string $sql, array $p = []) {
    $st = db_exec($sql, $p);
    return $st ? $st->fetchColumn(0) : null;
  }
}
if (!function_exists('db_row')) {
  function db_row(string $sql, array $p = []): ?array {
    $st = db_exec($sql, $p);
    $r  = $st ? $st->fetch(PDO::FETCH_ASSOC) : false;
    return $r ?: null;
  }
}
if (!function_exists('db_all')) {
  function db_all(string $sql, array $p = []): array {
    $st = db_exec($sql, $p);
    return $st ? $st->fetchAll(PDO::FETCH_ASSOC) : [];
  }
}

/* =========================
 * Вспомогательное
 * ========================= */
if (!function_exists('table_exists')) {
  function table_exists(string $table): bool {
    try {
      return (int)db_cell(
        "SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?",
        [$table]
      ) > 0;
    } catch (Throwable $e) { return false; }
  }
}

/** =========================
 *  Курс USD→UAH
 *  ========================= */
function fx_usd_uah_for_team(int $team_id): float {
  $fx = (float) db_cell("SELECT manual_fx FROM teams WHERE id=?", [$team_id]);
  if ($fx > 0) return $fx;

  if (function_exists('setting_get')) {
    $s = (float)((string)setting_get('manual_fx','0'));
    if ($s > 0) return $s;
  } else {
    $s = (float) db_cell("SELECT CAST(val AS DECIMAL(10,4)) FROM settings WHERE k='manual_fx' LIMIT 1");
    if ($s > 0) return $s;
  }

  $r = (float) db_cell("SELECT rate FROM fx_rates WHERE base='USD' AND quote='UAH' ORDER BY as_of DESC, created_at DESC LIMIT 1");
  return $r > 0 ? $r : 40.00;
}

/** =========================
 *  Таблица пополнений (служебная)
 *  ========================= */
function ensure_team_topups_schema(): void {
  try {
    db_exec("CREATE TABLE IF NOT EXISTS team_topups (
      id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
      team_id BIGINT UNSIGNED NOT NULL,
      amount_usd DECIMAL(14,2) NOT NULL,
      note VARCHAR(255) NULL,
      created_by BIGINT UNSIGNED NULL,
      created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      KEY idx_team (team_id), KEY idx_created (created_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
  } catch (Throwable $e) {}
}

function team_topups_add(int $team_id, float $amount_usd, ?string $note, ?int $admin_id, ?string $created_at = null): int {
  ensure_team_topups_schema();

  $dt = null;
  if ($created_at !== null && $created_at !== '') {
    $ts = strtotime(str_replace('T', ' ', $created_at));
    if ($ts !== false) $dt = date('Y-m-d H:i:s', $ts);
  }

  if ($dt) {
    db_exec("INSERT INTO team_topups(team_id,amount_usd,note,created_by,created_at) VALUES(?,?,?,?,?)",
      [$team_id, round($amount_usd,2), $note, $admin_id, $dt]);
  } else {
    db_exec("INSERT INTO team_topups(team_id,amount_usd,note,created_by,created_at) VALUES(?,?,?,?,NOW())",
      [$team_id, round($amount_usd,2), $note, $admin_id]);
  }
  return (int)db()->lastInsertId();
}

function team_topups_delete(int $team_id, int $topup_id): void {
  ensure_team_topups_schema();
  db_exec("DELETE FROM team_topups WHERE id=? AND team_id=?", [$topup_id, $team_id]);
}

function team_topups_last(int $team_id, int $limit=20): array {
  ensure_team_topups_schema();
  return db_all("SELECT * FROM team_topups WHERE team_id=? ORDER BY id DESC LIMIT ".(int)$limit, [$team_id]);
}

/** =========================
 *  Пополнения команды: ВСЁ ВРЕМЯ (без переносов)
 * ========================= */
function team_topups_sum_all(int $team_id): float {
  ensure_team_topups_schema();

  if (table_exists('team_rollovers')) {
    // Искомая сумма без «переносов»
    return (float) db_cell(
      "SELECT COALESCE(SUM(tt.amount_usd),0)
         FROM team_topups tt
    LEFT JOIN team_rollovers r ON r.topup_id = tt.id
        WHERE tt.team_id=? AND r.id IS NULL",
      [$team_id]
    );
  }

  // Фоллбек (на случай отсутствия таблицы переносов) — отсечём по метке в note
  return (float) db_cell(
    "SELECT COALESCE(SUM(
       CASE WHEN LOWER(COALESCE(note,'')) LIKE 'rollover%' OR LOWER(COALESCE(note,'')) LIKE 'перенос остатка%' THEN 0 ELSE amount_usd END
     ),0)
       FROM team_topups
      WHERE team_id=?",
    [$team_id]
  );
}

/** =========================
 *  Списания по команде: ВСЁ ВРЕМЯ (net: debit − hold)
 *  Привязка к команде — по снимку на момент операции (p.team_id_at_op).
 * ========================= */
function team_spend_uah_all(int $team_id, bool $include_hold=true): float {
  $row = db_row(
    "SELECT
        COALESCE(SUM(CASE WHEN p.type='debit' THEN p.amount_uah ELSE 0 END),0) AS debit_uah,
        COALESCE(SUM(CASE WHEN p.type='hold'  THEN p.amount_uah ELSE 0 END),0) AS hold_uah
       FROM payments p
  LEFT JOIN cards  c ON c.id=p.card_id
  LEFT JOIN buyers b ON b.id=c.buyer_id
  LEFT JOIN teams  t ON t.id=b.team_id
      WHERE COALESCE(p.team_id_at_op, t.id) = ?
        AND IFNULL(p.is_void,0)=0",
    [$team_id]
  );
  $debit = (float)($row['debit_uah'] ?? 0.0);
  $hold  = (float)($row['hold_uah']  ?? 0.0);
  return $include_hold ? ($debit - $hold) : $debit;
}

/* ========= Совместимость с прежним кодом (периодные функции) ========= */

/** Возврат границ месяца; оставлено для совместимости со страницей admin/team_balance.php */
function month_bounds(?string $ym=null): array {
  $t    = $ym ? strtotime($ym.'-01 00:00:00') : time();
  $from = date('Y-m-01 00:00:00', $t);
  $to   = date('Y-m-01 00:00:00', strtotime('+1 month', strtotime($from)));
  return [$from,$to];
}
function ym_from_date(string $date): int { return (int)date('Ym', strtotime($date)); }

/** Старые сигнатуры — теперь считают за всё время */
function team_topups_sum(int $team_id, string $_from, string $_to): float {
  return team_topups_sum_all($team_id);
}
function team_spend_uah(int $team_id, string $_from, string $_to, bool $include_hold=true): float {
  return team_spend_uah_all($team_id, $include_hold);
}

/** =========================
 *  Главный расчёт: ОБЩИЙ БАЛАНС КОМАНДЫ (за всё время)
 * ========================= */
function team_balance_calc(int $team_id, string $_from_unused = '', string $_to_unused = '', bool $include_hold=true): array {
  $fx           = fx_usd_uah_for_team($team_id);
  $topups_usd   = team_topups_sum_all($team_id);
  $spend_uah    = team_spend_uah_all($team_id, $include_hold);
  $spend_usd    = $fx > 0 ? $spend_uah / $fx : 0.0;
  $remain_usd   = round($topups_usd - $spend_usd, 2);
  $remain_uah   = round($remain_usd * $fx, 2);

  return [
    'mode'        => 'all_time',
    'fx'          => (float)$fx,
    'topups_usd'  => round($topups_usd, 2),
    'spend_uah'   => round($spend_uah, 2),
    'spend_usd'   => round($spend_usd, 2),
    'remain_usd'  => $remain_usd,
    'remain_uah'  => $remain_uah,
    'from'        => null,
    'to'          => null,
  ];
}

/* =========================
 *  Переносы — полностью отключены (заглушки)
 * ========================= */
function ensure_team_rollovers_schema(): void { /* no-op */ }
function team_rollover_exists(int $team_id, int $src_ym): bool { return false; }
function team_rollover_apply(int $team_id, string $from, string $to, float $amount_usd, int $admin_id): array {
  return ['topup_id'=>0,'rollover_id'=>0];
}
function team_rollover_cancel(int $team_id, int $src_ym): bool { return false; }
function team_rollover_get(int $team_id, int $src_ym): ?array { return null; }
