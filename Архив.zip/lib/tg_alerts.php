<?php
declare(strict_types=1);

/**
 * Telegram Alerts — reworked to:
 *  - send low balance / low limit alerts EVERY time the value under threshold CHANGES
 *  - daily reminder for cards with status=in_work to each drop chat
 *  - configurable morning time (HH:MM) and timezone via settings
 *  - robust settings storage (supports both settings(k,val) and settings(key,value))
 *  - safe operation on shared hostings (no fatal errors if some optional libs absent)
 */

require_once __DIR__.'/db.php';
require_once __DIR__.'/settings.php';
@require_once __DIR__.'/telegram.php';
@require_once __DIR__.'/balance.php'; // for cards_balance_column()
@require_once __DIR__.'/limit.php';   // for limit schema presence

/* ----------------------------- Helpers ----------------------------- */

function _ta_db_has_table(string $table): bool {
    try {
        return (int)db_col("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?", [$table]) > 0;
    } catch (Throwable $e) { return false; }
}

function _ta_db_has_column(string $table, string $col): bool {
    try {
        return (int)db_col("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?", [$table,$col]) > 0;
    } catch (Throwable $e) { return false; }
}

function _ta_send_telegram($chat_id, string $text, array $opts = []): array {
    $ok = false; $error = null; $payload = ['chat_id'=>$chat_id, 'text'=>$text, 'disable_web_page_preview'=>true];
    if (isset($opts['parse_mode'])) $payload['parse_mode'] = (string)$opts['parse_mode'];
    try {
        if (function_exists('telegram_send')) {
            $ok = telegram_send($chat_id, $text, $opts) ? true : false;
        } elseif (function_exists('telegram_api')) {
            $resp = telegram_api('sendMessage', $payload, $raw, $err);
            $ok = is_array($resp) && !empty($resp['ok']);
            if (!$ok) $error = $err ?: 'telegram_api error';
        } else {
            $error = 'No telegram transport';
        }
    } catch (Throwable $e) {
        $ok = false; $error = $e->getMessage();
    }
    return ['ok'=>$ok, 'error'=>$error];
}

/* ------------------------ Schema & dedup state ------------------------ */

function tg_alerts_bootstrap_schema(): void {
    try {
        // State for "value under threshold changed"
        db_exec("CREATE TABLE IF NOT EXISTS tg_alerts_state (
            alert_type   VARCHAR(32)  NOT NULL,
            drop_id      BIGINT       NOT NULL DEFAULT 0,
            card_id      BIGINT       NOT NULL DEFAULT 0,
            last_value   DECIMAL(14,2) NULL,
            last_sent_at DATETIME     NULL,
            PRIMARY KEY (alert_type, drop_id, card_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Dedupe per-day for morning digest
        db_exec("CREATE TABLE IF NOT EXISTS tg_alerts_sent (
            sent_on     DATE         NOT NULL,
            alert_type  VARCHAR(32)  NOT NULL,
            drop_id     BIGINT       NOT NULL DEFAULT 0,
            card_id     BIGINT       NOT NULL DEFAULT 0,
            hash        VARCHAR(64)  NOT NULL,
            PRIMARY KEY (sent_on, alert_type, drop_id, card_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {
        @error_log('[tg_alerts_bootstrap_schema] '.$e->getMessage());
    }
}

function _ta_state_get(string $type, int $drop_id, int $card_id): ?array {
    try {
        return db_row("SELECT last_value, last_sent_at FROM tg_alerts_state WHERE alert_type=? AND drop_id=? AND card_id=?",
                      [$type,$drop_id,$card_id]);
    } catch (Throwable $e) { return null; }
}
function _ta_state_set(string $type, int $drop_id, int $card_id, $value): void {
    try {
        db_exec("INSERT INTO tg_alerts_state(alert_type,drop_id,card_id,last_value,last_sent_at)
                 VALUES(?,?,?,?,NOW())
                 ON DUPLICATE KEY UPDATE last_value=VALUES(last_value), last_sent_at=VALUES(last_sent_at)",
                 [$type,$drop_id,$card_id,$value]);
    } catch (Throwable $e) {}
}
function _ta_state_clear(string $type, int $drop_id, int $card_id): void {
    try {
        db_exec("DELETE FROM tg_alerts_state WHERE alert_type=? AND drop_id=? AND card_id=?", [$type,$drop_id,$card_id]);
    } catch (Throwable $e) {}
}

/* ------------------------ Config loader ------------------------ */

function tg_alerts_load_config(): array {
    // defaults
    $tz = @date_default_timezone_get();
    $cfg = [
        'enabled_low_balance'    => true,
        'threshold_low_balance'  => 15000,
        'template_low_balance'   =>
            "Баланс на карте {bank} ••••{last4} < {threshold} грн\n".
            "Баланс: {balance} грн\n".
            "Остаток лимита: {limit_remaining} грн\n".
            "{tg_nick}",

        'enabled_low_limit'      => true,
        'threshold_low_limit'    => 15000,
        'template_low_limit'     =>
            "Лимит по карте {bank} ••••{last4} < {threshold} грн\n".
            "Остаток лимита: {limit_remaining} грн\n".
            "Баланс: {balance} грн\n".
            "{tg_nick}",

        'enabled_morning'        => true,
        'morning_time'           => '09:00',
        'template_morning'       =>
            "Ежедневное напоминание: карты в статусе in_work\n".
            "{cards}\n{tg_nick}",

        'tz'                     => $tz ?: 'Europe/Kyiv',
    ];

    // read from settings(k,val)
    try {
        if (_ta_db_has_table('settings')) {
            // try k/val
            $rows = db_all("SELECT `k` AS `key`, `val` AS `value` FROM `settings` WHERE `k` LIKE 'tg.%'");
            foreach ($rows as $r) {
                $k = (string)$r['key']; $v = $r['value'];
                if ($k==='tg.enabled_low_balance')     $cfg['enabled_low_balance'] = (bool)$v;
                if ($k==='tg.threshold_low_balance')   $cfg['threshold_low_balance'] = (int)$v;
                if ($k==='tg.template_low_balance')    $cfg['template_low_balance'] = (string)$v;

                if ($k==='tg.enabled_low_limit')       $cfg['enabled_low_limit'] = (bool)$v;
                if ($k==='tg.threshold_low_limit')     $cfg['threshold_low_limit'] = (int)$v;
                if ($k==='tg.template_low_limit')      $cfg['template_low_limit'] = (string)$v;

                if ($k==='tg.enabled_morning')         $cfg['enabled_morning'] = (bool)$v;
                if ($k==='tg.template_morning')        $cfg['template_morning'] = (string)$v;
                if ($k==='tg.morning_time')            $cfg['morning_time'] = (string)$v;
                if ($k==='tg.tz')                      $cfg['tz'] = (string)$v;
            }
            // try key/value variant
            $rows2 = db_all("SELECT `key`,`value` FROM `settings` WHERE `key` LIKE 'tg.%'");
            foreach ($rows2 as $r) {
                $k = (string)$r['key']; $v = $r['value'];
                if ($k==='tg.enabled_low_balance')     $cfg['enabled_low_balance'] = (bool)$v;
                if ($k==='tg.threshold_low_balance')   $cfg['threshold_low_balance'] = (int)$v;
                if ($k==='tg.template_low_balance')    $cfg['template_low_balance'] = (string)$v;

                if ($k==='tg.enabled_low_limit')       $cfg['enabled_low_limit'] = (bool)$v;
                if ($k==='tg.threshold_low_limit')     $cfg['threshold_low_limit'] = (int)$v;
                if ($k==='tg.template_low_limit')      $cfg['template_low_limit'] = (string)$v;

                if ($k==='tg.enabled_morning')         $cfg['enabled_morning'] = (bool)$v;
                if ($k==='tg.template_morning')        $cfg['template_morning'] = (string)$v;
                if ($k==='tg.morning_time')            $cfg['morning_time'] = (string)$v;
                if ($k==='tg.tz')                      $cfg['tz'] = (string)$v;
            }
        }
    } catch (Throwable $e) {
        @error_log('[tg_alerts_load_config] '.$e->getMessage());
    }

    return $cfg;
}

/* ------------------------ Data access ------------------------ */

function _ta_cards_with_drop_chats(bool $only_in_work=false): array {
    $rows = [];
    try {
        $cards_table = 'cards'; $drops_table='drops';
        if (!_ta_db_has_table($cards_table) || !_ta_db_has_table($drops_table)) return [];

        $has_drop_cards = _ta_db_has_table('drop_cards');
        $drop_link_via_cards = _ta_db_has_column('cards','drop_id');

        // columns
        $bal_col = _ta_db_has_column('cards','balance_uah') ? 'c.balance_uah' : 'c.balance';
        if (!_ta_db_has_column('cards','balance_uah') && function_exists('cards_balance_column')) {
            try { $bc = cards_balance_column(); $bal_col = 'c.`'.$bc.'`'; } catch (Throwable $e) {}
        }
        $lim_rem_col = _ta_db_has_column('cards','limit_remaining_uah') ? 'c.limit_remaining_uah' : null;
        $lim_cap_col = _ta_db_has_column('cards','limit_cap_uah') ? 'c.limit_cap_uah' : null;
        $status_cond = $only_in_work ? " AND c.status='in_work' " : '';

        $select_more = '';
        $select_more .= $bal_col ? ", {$bal_col} AS balance" : ", NULL AS balance";
        $select_more .= $lim_rem_col ? ", {$lim_rem_col} AS limit_remaining" : ", NULL AS limit_remaining";
        $select_more .= $lim_cap_col ? ", {$lim_cap_col} AS limit_cap" : ", NULL AS limit_cap";

        if ($has_drop_cards){
            $sql = "SELECT dc.drop_id, d.telegram_chat_id AS chat_id, d.tg_nick,
                           c.id AS card_id, c.bank, c.pan_last4 AS last4, c.status
                           {$select_more}
                    FROM drop_cards dc
                    JOIN cards c ON c.id=dc.card_id
                    JOIN drops d ON d.id=dc.drop_id
                    WHERE d.telegram_chat_id IS NOT NULL {$status_cond}";
            $rows = db_all($sql, []);
        } elseif ($drop_link_via_cards){
            $sql = "SELECT c.drop_id, d.telegram_chat_id AS chat_id, d.tg_nick,
                           c.id AS card_id, c.bank, c.pan_last4 AS last4, c.status
                           {$select_more}
                    FROM cards c
                    JOIN drops d ON d.id=c.drop_id
                    WHERE d.telegram_chat_id IS NOT NULL {$status_cond}";
            $rows = db_all($sql, []);
        } else {
            // no relation -> nothing to send
            return [];
        }

        // normalize
        $out = [];
        foreach ($rows as $r){
            $drop_id = (int)($r['drop_id'] ?? 0);
            $chat_id = $r['chat_id'] ?? null;
            if (!$chat_id) continue;

            $balance = isset($r['balance']) ? (float)$r['balance'] : 0.0;
            $lim_rem = isset($r['limit_remaining']) ? (float)$r['limit_remaining'] : null;
            $lim_cap = isset($r['limit_cap']) ? (float)$r['limit_cap'] : null;
            if ($lim_rem === null && $lim_cap !== null) $lim_rem = $lim_cap;

            $bank = (string)($r['bank'] ?? '');
            $brand = $bank==='mono' ? 'Monobank' : ($bank==='privat' ? 'PrivatBank' : ($bank ?: 'Card'));
            $last4 = (string)($r['last4'] ?? '');

            $out[] = [
                'drop_id' => $drop_id,
                'chat_id' => $chat_id,
                'card_id' => (int)$r['card_id'],
                'status'  => $r['status'] ?? null,
                'bank'    => $bank,
                'brand'   => $brand,
                'last4'   => $last4,
                'balance' => $balance,
                'limit_remaining' => $lim_rem,
                'tg_nick' => $r['tg_nick'] ?? '',
            ];
        }
        return $out;
    } catch (Throwable $e) {
        @error_log('[ta_cards] '.$e->getMessage());
        return [];
    }
}

/* ------------------------ Formatting ------------------------ */

function _ta_format_tpl(string $tpl, array $row, array $vars = []): string {
    $repl = [
        '{brand}'           => (string)($row['brand'] ?? ''),
        '{bank}'            => (string)($row['bank'] ?? ''),
        '{last4}'           => (string)($row['last4'] ?? ''),
        '{balance}'         => number_format((float)($row['balance'] ?? 0), 2, '.', ''),
        '{limit_remaining}' => number_format((float)($row['limit_remaining'] ?? 0), 2, '.', ''),
        '{threshold}'       => number_format((float)($vars['threshold'] ?? 0), 0, '.', ''),
        '{tg_nick}'         => (string)($row['tg_nick'] ?? ''),
    ];
    return strtr($tpl, $repl);
}

/* ------------------------ Alert runners ------------------------ */

function tg_alerts_run_low_balance(array $cfg, array $opts = []): array {
    $threshold = (int)($cfg['threshold_low_balance'] ?? 15000);
    $dry  = !empty($opts['dry']) || !empty($opts['dry_run']);
    $force= !empty($opts['force']);
    $rows = _ta_cards_with_drop_chats(false);
    $sent=0; $skipped=0; $errors=0; $details=[];

    foreach ($rows as $r){
        $drop_id = (int)$r['drop_id']; $card_id = (int)$r['card_id']; $chat_id = $r['chat_id'];
        $balance = (float)$r['balance'];
        if ($balance >= $threshold) { _ta_state_clear('low_balance', $drop_id, $card_id); $skipped++; continue; }

        $value_key = (int)floor($balance); // compare by integer UAH to avoid spam on minor cents
        $need = $force;
        if (!$need){
            $state = _ta_state_get('low_balance', $drop_id, $card_id);
            if (!$state || (int)floor((float)($state['last_value'] ?? -1)) !== $value_key) $need = true;
        }

        if (!$need) { $skipped++; $details[]=['card_id'=>$card_id,'why'=>'unchanged_under_threshold','balance'=>$balance]; continue; }

        $msg = _ta_format_tpl((string)$cfg['template_low_balance'], $r, ['threshold'=>$threshold]);
        if (!$dry){
            $res = _ta_send_telegram($chat_id, $msg, ['parse_mode'=>'HTML']);
            if ($res['ok']) {
                _ta_state_set('low_balance', $drop_id, $card_id, $balance);
                $sent++;
            } else { $errors++; $details[]=['card_id'=>$card_id,'error'=>$res['error']]; }
        } else {
            $details[]=['card_id'=>$card_id,'dry'=>true,'chat_id'=>$chat_id,'text'=>$msg];
            $sent++; // count as would send
        }
    }
    return ['type'=>'low_balance','sent'=>$sent,'skipped'=>$skipped,'errors'=>$errors,'details'=>$details];
}

function tg_alerts_run_low_limit(array $cfg, array $opts = []): array {
    $threshold = (int)($cfg['threshold_low_limit'] ?? 15000);
    $dry  = !empty($opts['dry']) || !empty($opts['dry_run']);
    $force= !empty($opts['force']);
    $rows = _ta_cards_with_drop_chats(false);
    $sent=0; $skipped=0; $errors=0; $details=[];

    foreach ($rows as $r){
        $drop_id = (int)$r['drop_id']; $card_id = (int)$r['card_id']; $chat_id = $r['chat_id'];
        $limit_remaining = (float)($r['limit_remaining'] ?? 0);
        if ($limit_remaining >= $threshold) { _ta_state_clear('low_limit', $drop_id, $card_id); $skipped++; continue; }

        $value_key = (int)floor($limit_remaining);
        $need = $force;
        if (!$need){
            $state = _ta_state_get('low_limit', $drop_id, $card_id);
            if (!$state || (int)floor((float)($state['last_value'] ?? -1)) !== $value_key) $need = true;
        }

        if (!$need) { $skipped++; $details[]=['card_id'=>$card_id,'why'=>'unchanged_under_threshold','limit_remaining'=>$limit_remaining]; continue; }

        $msg = _ta_format_tpl((string)$cfg['template_low_limit'], $r, ['threshold'=>$threshold]);
        if (!$dry){
            $res = _ta_send_telegram($chat_id, $msg, ['parse_mode'=>'HTML']);
            if ($res['ok']) {
                _ta_state_set('low_limit', $drop_id, $card_id, $limit_remaining);
                $sent++;
            } else { $errors++; $details[]=['card_id'=>$card_id,'error'=>$res['error']]; }
        } else {
            $details[]=['card_id'=>$card_id,'dry'=>true,'chat_id'=>$chat_id,'text'=>$msg];
            $sent++;
        }
    }
    return ['type'=>'low_limit','sent'=>$sent,'skipped'=>$skipped,'errors'=>$errors,'details'=>$details];
}

function tg_alerts_run_morning(array $cfg, array $opts = []): array {
    $dry   = !empty($opts['dry']) || !empty($opts['dry_run']);
    $force = !empty($opts['force']);
    $tz    = (string)($cfg['tz'] ?? @date_default_timezone_get() ?: 'Europe/Kyiv');
    $time  = (string)($cfg['morning_time'] ?? '09:00');

    $prev_tz = @date_default_timezone_get();
    if ($tz) @date_default_timezone_set($tz);

    $now_time = date('H:i');
    $today = date('Y-m-d');

    $sent=0; $skipped=0; $errors=0; $details=[];

    if (!$force && $now_time !== $time) {
        @date_default_timezone_set($prev_tz ?: 'UTC');
        return ['type'=>'morning','sent'=>0,'skipped'=>0,'errors'=>0,'details'=>[['why'=>'time_gate','now'=>$now_time,'expected'=>$time,'tz'=>$tz]]];
    }

    $rows = _ta_cards_with_drop_chats(true); // status=in_work
    // group by drop/chat
    $byDrop = [];
    foreach ($rows as $r){
        $drop_id = (int)$r['drop_id']; $chat_id = $r['chat_id'];
        if (!$chat_id) continue;
        $byDrop[$drop_id]['chat_id'] = $chat_id;
        $byDrop[$drop_id]['tg_nick'] = $r['tg_nick'] ?? '';
        $byDrop[$drop_id]['cards'][] = $r;
    }

    foreach ($byDrop as $drop_id => $info){
        $chat_id = $info['chat_id'];
        $cards = $info['cards'] ?? [];
        if (!$cards) { $skipped++; continue; }

        // dedupe per day
        $already = (int)db_col("SELECT COUNT(*) FROM tg_alerts_sent WHERE sent_on=? AND alert_type='morning' AND drop_id=?",
                                [$today, $drop_id]);
        if ($already && !$force) { $skipped++; $details[]=['drop_id'=>$drop_id,'why'=>'dedup_today']; continue; }

        $lines = [];
        foreach ($cards as $c){
            $lines[] = "• {$c['brand']} ••••{$c['last4']} — статус in_work";
        }
        $body = implode("\n", $lines);
        $tpl = (string)$cfg['template_morning'];
        $msg = strtr($tpl, [
            '{cards}'  => $body,
            '{tg_nick}'=> (string)($info['tg_nick'] ?? ''),
        ]);

        if (!$dry){
            $res = _ta_send_telegram($chat_id, $msg, ['parse_mode'=>'HTML']);
            if ($res['ok']) {
                db_exec("INSERT INTO tg_alerts_sent(sent_on,alert_type,drop_id,card_id,hash) VALUES(?, 'morning', ?, 0, SHA1(?))
                         ON DUPLICATE KEY UPDATE hash=VALUES(hash)", [$today, $drop_id, $msg]);
                $sent++;
            } else { $errors++; $details[]=['drop_id'=>$drop_id,'error'=>$res['error']]; }
        } else {
            $details[]=['drop_id'=>$drop_id,'dry'=>true,'chat_id'=>$chat_id,'text'=>$msg];
            $sent++;
        }
    }

    @date_default_timezone_set($prev_tz ?: 'UTC');
    return ['type'=>'morning','sent'=>$sent,'skipped'=>$skipped,'errors'=>$errors,'details'=>$details];
}

function tg_alerts_run_all(array $opts = []): array {
    tg_alerts_bootstrap_schema();
    $cfg = tg_alerts_load_config();
    $result = ['cfg'=>$cfg];

    if (!empty($cfg['enabled_low_balance'])) $result['low_balance'] = tg_alerts_run_low_balance($cfg, $opts);
    if (!empty($cfg['enabled_low_limit']))   $result['low_limit']   = tg_alerts_run_low_limit($cfg, $opts);
    if (!empty($cfg['enabled_morning']))     $result['morning']     = tg_alerts_run_morning($cfg, $opts);

    return $result;
}

// EOF
