<?php
require_once __DIR__.'/db.php'; require_once __DIR__.'/helpers.php';
if (session_status()!==PHP_SESSION_ACTIVE) session_start();
function auth_user(){return $_SESSION['user']??null;} function auth_require(){ if(!auth_user()){header('Location:/login.php');exit;} }
function auth_is_admin(){return auth_user()&&auth_user()['role']==='admin';} function auth_require_admin(){ if(!auth_is_admin()){http_response_code(403);exit('403');}}
function auth_login($email,$password):bool{ $u=db_exec('SELECT * FROM users WHERE email=? LIMIT 1',[$email])->fetch(); if(!$u||!password_verify($password,$u['password'])) return false; $_SESSION['user']=['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'role'=>$u['role']]; try{db_exec('INSERT INTO audit_logs(user_id,entity_type,action,created_at) VALUES(?,?,?,NOW())',[$u['id'],'auth','login']);}catch(Throwable $e){} session_regenerate_id(true); return true; }
function auth_logout(){ if($u=auth_user()){ try{db_exec('INSERT INTO audit_logs(user_id,entity_type,action,created_at) VALUES(?,?,?,NOW())',[$u['id'],'auth','logout']);}catch(Throwable $e){} } $_SESSION=[]; session_destroy(); header('Location:/login.php'); exit; }