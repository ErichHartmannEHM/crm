<?php
declare(strict_types=1);

if (session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

function drop_is_logged(): bool {
  return !empty($_SESSION['drop_id']);
}
function drop_id(): ?int {
  return drop_is_logged() ? (int)$_SESSION['drop_id'] : null;
}
function drop_require(): void {
  if (!drop_is_logged()) {
    header('Location: /drop/login.php'); exit;
  }
}
function drop_login(int $drop_id): void {
  $_SESSION['drop_id'] = $drop_id;
}
function drop_logout(): void {
  unset($_SESSION['drop_id']);
}
