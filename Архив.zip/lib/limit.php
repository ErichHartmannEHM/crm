<?php
declare(strict_types=1);

require_once __DIR__.'/db.php';

/**
 * Единая логика месячного лимита по карте (UAH)
 * Поля таблицы cards:
 *   - limit_cap_uah DECIMAL(14,2) NOT NULL DEFAULT 100000
 *   - limit_remaining_uah DECIMAL(14,2) NULL
 *   - limit_last_reset_month INT NULL  -- YYYYMM последнего пересчёта
 *
 * Поведение:
 *   - На дебите (списание) уменьшаем remaining; если уходит в минус — блокируем операцию.
 *   - На пополнении (topup) лимит НЕ меняем; на холде (hold/возврат) возвращаем в remaining, но не больше cap.
 *   - Каждый месяц (при первом обращении) делаем reset: remaining = cap, last_reset = текущий YYYYMM.
 */

function limit_bootstrap_schema(): void {
    try {
        // Добавляем колонки, если их нет (совместимо с MySQL 5.7/8)
        $cols = db_all("SHOW COLUMNS FROM `cards`");
        $have = [];
        foreach ($cols as $c) { $have[$c['Field']] = true; }

        if (empty($have['limit_cap_uah'])) {
            db_exec("ALTER TABLE `cards` ADD COLUMN `limit_cap_uah` DECIMAL(14,2) NOT NULL DEFAULT 100000 AFTER `status`");
        }
        if (empty($have['limit_remaining_uah'])) {
            db_exec("ALTER TABLE `cards` ADD COLUMN `limit_remaining_uah` DECIMAL(14,2) NULL AFTER `limit_cap_uah`");
        }
        if (empty($have['limit_last_reset_month'])) {
            db_exec("ALTER TABLE `cards` ADD COLUMN `limit_last_reset_month` INT NULL AFTER `limit_remaining_uah`");
        }

        // Инициализируем null-ы
        db_exec("UPDATE `cards`
                   SET `limit_remaining_uah` = IFNULL(`limit_remaining_uah`, `limit_cap_uah`),
                       `limit_last_reset_month` = IFNULL(`limit_last_reset_month`, EXTRACT(YEAR_MONTH FROM NOW()))
                 WHERE `limit_remaining_uah` IS NULL OR `limit_last_reset_month` IS NULL");
    } catch (Throwable $e) {
        // молча: чтобы UI не падал, даже если нет прав ALTER
    }
}

/** Сбросить лимит, если наступил новый месяц. $card_id = null — для всех. */
function limit_maybe_monthly_reset(?int $card_id = null): void {
    $ym = (int)date('Ym');
    if ($card_id) {
        db_exec("UPDATE `cards`
                    SET `limit_remaining_uah` = `limit_cap_uah`,
                        `limit_last_reset_month` = ?
                  WHERE id = ? AND (limit_last_reset_month IS NULL OR limit_last_reset_month <> ?)",
                [$ym, $card_id, $ym]);
    } else {
        db_exec("UPDATE `cards`
                    SET `limit_remaining_uah` = `limit_cap_uah`,
                        `limit_last_reset_month` = ?
                  WHERE (limit_last_reset_month IS NULL OR limit_last_reset_month <> ?)",
                [$ym, $ym]);
    }
}

/**
 * Применить операцию к лимиту.
 * @param int    $card_id
 * @param string $type   'debit' | 'topup' | 'hold'
 * @param float  $amount_uah  >0
 * @return array{ok:bool,error:?string,limit_remaining:float}
 */
function limit_apply_operation(int $card_id, string $type, float $amount_uah): array {
    limit_bootstrap_schema();
    limit_maybe_monthly_reset($card_id);

    // Берём cap/remaining
    $row = db_row("SELECT limit_cap_uah, limit_remaining_uah FROM `cards` WHERE id = ?", [$card_id]);
    if (!$row) return ['ok'=>false,'error'=>'Карта не найдена','limit_remaining'=>0.0];

    $cap = (float)($row['limit_cap_uah'] ?? 100000.0);
    $rem = (float)($row['limit_remaining_uah'] ?? $cap);

    if ($type === 'debit') {
        $new = $rem - $amount_uah;
        if ($new < -0.00001) { // не даём уйти ниже нуля
            return ['ok'=>false,'error'=>'Превышен месячный лимит','limit_remaining'=>$rem];
        }
        db_exec("UPDATE `cards` SET limit_remaining_uah = ? WHERE id = ?", [max(0.0,$new), $card_id]);
        return ['ok'=>true,'error'=>null,'limit_remaining'=>max(0.0,$new)];
    } elseif ($type === 'hold') {
        $new = $rem + $amount_uah;
        if ($new > $cap) $new = $cap;
        db_exec("UPDATE `cards` SET limit_remaining_uah = ? WHERE id = ?", [$new, $card_id]);
        return ['ok'=>true,'error'=>null,'limit_remaining'=>$new];
    } elseif ($type === 'topup') {
        // Пополнение не влияет на месячный лимит
        return ['ok'=>true,'error'=>null,'limit_remaining'=>$rem];
    } else {
        return ['ok'=>false,'error'=>'Неизвестный тип операции','limit_remaining'=>$rem];
    }
}

/** Сколько дней до первого числа следующего месяца */
function limit_days_to_reset(): int {
    $now = new DateTime('now');
    $firstNext = (new DateTime('first day of next month'))->setTime(0,0,0);
    return (int)$now->diff($firstNext)->format('%a');
}

/** Пересчитать limit_remaining_uah за текущий месяц.
 * Формула: new = max(0, min(cap, cap - SUM(debit) + SUM(hold))) для каждой карты.
 * Если $card_id == null — для всех карт.
 * Возвращает количество затронутых карт.
 */
function limit_recalc_for_current_month(?int $card_id = null): int {
    $whereCard = $card_id ? " WHERE c.id = :cid" : "";
    $sql = "
        UPDATE cards c
        JOIN (
            SELECT
                c2.id AS card_id,
                c2.limit_cap_uah AS cap,
                GREATEST(
                    0,
                    LEAST(
                        c2.limit_cap_uah,
                        c2.limit_cap_uah
                          - COALESCE(SUM(CASE WHEN p.type='debit' THEN p.amount_uah END),0)
                          + COALESCE(SUM(CASE WHEN p.type='hold'  THEN p.amount_uah END),0)
                    )
                ) AS new_remaining
            FROM cards c2
            LEFT JOIN payments p ON p.card_id = c2.id
              AND DATE_FORMAT(p.created_at,'%Y%m') = DATE_FORMAT(NOW(),'%Y%m')
              AND (p.is_void IS NULL OR p.is_void=0)
              AND p.type IN ('debit','hold')
              AND COALESCE(p.is_void,0)=0
            " . ($card_id ? "WHERE c2.id = :cid" : "") . "
            GROUP BY c2.id, c2.limit_cap_uah
        ) x ON x.card_id = c.id
        SET c.limit_remaining_uah = x.new_remaining,
            c.limit_last_reset_month = EXTRACT(YEAR_MONTH FROM NOW())
        " . ($card_id ? "WHERE c.id = :cid" : "") . "
    ";
    try {
        $stmt = db_exec($sql, $card_id ? [':cid'=>$card_id] : []);
        return (int)$stmt->rowCount();
    } catch (Throwable $e) {
        return 0;
    }
}

