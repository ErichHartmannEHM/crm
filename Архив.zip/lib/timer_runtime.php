<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/telegram.php';
@require_once __DIR__ . '/scheduler.php'; // for has_col(), statuses_*, recipients_for_schedule()

/**
 * Timer runtime without cron.
 * 
 * How it works:
 *  - Called on every admin page view (via /admin/timer_tick.php beacon) and on every bot webhook hit.
 *  - Executes at most once per minute (Kyiv time) using the 'settings' table as a simple mutex.
 *  - For each active schedule in tg_broadcast_schedules:
 *      * respects mask of weekdays (if present and non-zero),
 *      * for each time slot time1..time3: if now >= slot and the slot is not sent today -> send and set the bit in sent_mask.
 *  - Prevents duplicate concurrent sends using MySQL GET_LOCK per-schedule.
 */

if (!function_exists('kyiv_tz')) {
    function kyiv_tz(): DateTimeZone {
        try { return new DateTimeZone('Europe/Kyiv'); }
        catch (Throwable $e) { return new DateTimeZone('Europe/Kiev'); }
    }
}

/** Append line into storage/logs/telegram/broadcast_YYYYMMDD.log */
if (!function_exists('tg_timer_log')) {
    function tg_timer_log(string $line): void {
        try {
            $base = realpath(__DIR__ . '/../storage/logs/telegram');
            if ($base === false) $base = __DIR__ . '/../storage/logs/telegram';
            if (!is_dir($base)) @mkdir($base, 0777, true);
            $ts   = (new DateTimeImmutable('now', kyiv_tz()))->format('Y-m-d H:i:s');
            $file = $base . '/broadcast_' . (new DateTimeImmutable('now', kyiv_tz()))->format('Ymd') . '.log';
            @file_put_contents($file, '['.$ts.'] '.$line.PHP_EOL, FILE_APPEND);
        } catch (Throwable $e) {}
    }
}

if (!function_exists('tg_timer_tick')) {
    /**
     * Execute due schedules (idempotent within a minute).
     * @return array report ['skipped'=>..., 'sent'=>int, 'errors'=>int, 'details'=>[...]]
     */
    function tg_timer_tick(bool $force = false): array {
        $pdo = db();
        $now = new DateTimeImmutable('now', kyiv_tz());
        $today = $now->format('Y-m-d');
        $hhmm  = $now->format('H:i');
        $minuteKey = $now->format('Y-m-d H:i');

        // Run at most once per minute unless forced
        if (!$force) {
            $last = setting_get('tg_timer_last_minute', '');
            if ($last === $minuteKey) {
                return ['skipped' => 'already ticked this minute'];
            }
            setting_set('tg_timer_last_minute', $minuteKey);
        }

        $sent = 0; $errors = 0; $details = [];

        // Build WHERE clause respecting optional enabled column
        $where = 'active=1';
        try {
            $hasEnabled = false;
            // Use information_schema via has_col() when available
            if (function_exists('has_col')) {
                $hasEnabled = has_col($pdo, 'tg_broadcast_schedules', 'enabled');
            }
            if ($hasEnabled) $where .= ' AND enabled=1';
        } catch (Throwable $e) {}

        try {
            $timers = db_all("SELECT * FROM tg_broadcast_schedules WHERE $where ORDER BY id ASC");
        } catch (Throwable $e) {
            tg_timer_log('ERROR: read schedules failed: '.$e->getMessage());
            return ['sent'=>0,'errors'=>1,'details'=>['read_failed'=>$e->getMessage()]];
        }

        foreach ($timers as $t) {
            $id = (int)$t['id'];

            // Weekday mask check (bit 0 = Monday, 6 = Sunday), if mask exists and non-zero
            $maskOk = true;
            try {
                if (array_key_exists('mask', $t)) {
                    $mask = (int)$t['mask'];
                    if ($mask !== 0) {
                        $w = (int)$now->format('N'); // 1..7
                        $bit = 1 << ($w - 1);
                        $maskOk = (($mask & $bit) !== 0);
                    }
                }
            } catch (Throwable $e) {}
            if (!$maskOk) { $details[] = "skip#$id mask"; continue; }

            $lockKey = 'tg_timer_sched_'.$id;
            $gotLock = false;
            try {
                $gotLock = (bool) db_col("SELECT GET_LOCK(?, 0)", [$lockKey]);
            } catch (Throwable $e) {}
            if (!$gotLock) { $details[] = "skip#$id lock"; continue; }

            try {
                // Re-read row under lock
                $row = db_row("SELECT * FROM tg_broadcast_schedules WHERE id=?", [$id]);
                if (!$row) { $details[]="skip#$id missing"; continue; }

                $sentMask = (int)($row['sent_mask'] ?? 0);
                $lastDate = (string)($row['last_sent_date'] ?? '');
                if ($lastDate !== $today) { $sentMask = 0; $lastDate = $today; }

                // Collect slots
                $slots = [];
                $t1 = substr((string)($row['time1'] ?? ''), 0, 5);
                $t2 = substr((string)($row['time2'] ?? ''), 0, 5);
                $t3 = substr((string)($row['time3'] ?? ''), 0, 5);
                if ($t1) $slots[] = ['idx'=>0, 'hhmm'=>$t1];
                if ($t2) $slots[] = ['idx'=>1, 'hhmm'=>$t2];
                if ($t3) $slots[] = ['idx'=>2, 'hhmm'=>$t3];

                // Determine due slots (catch-up: now >= slot and not sent today)
                $dueIdx = [];
                foreach ($slots as $sl) {
                    $bit = 1 << $sl['idx'];
                    if (($sentMask & $bit) !== 0) continue;
                    // compare lexicographically 'H:i'
                    if ($hhmm >= $sl['hhmm']) $dueIdx[] = $sl['idx'];
                }
                if (!$dueIdx) { $details[]="skip#$id no-due"; continue; }

                // Build recipients and send
                $message = (string)$row['message'];
                if ($message === '') { $details[]="skip#$id empty-msg"; continue; }

                $targets = [];
                if (function_exists('recipients_for_schedule')) {
                    try { $targets = recipients_for_schedule($pdo, $row); } catch (Throwable $e) { $targets = []; }
                } else {
                    // fallback: send to team chats
                    $targets = db_all("SELECT DISTINCT chat_id FROM team_telegram_chats WHERE is_active=1");
                    $targets = array_map(function($r){ return ['chat_id'=>(string)$r['chat_id'], 'thread'=>null]; }, $targets);
                }

                $okForThis = 0;
                foreach ($targets as $tg) {
                    $chat = (string)($tg['chat_id'] ?? '');
                    if ($chat === '') continue;
                    $params = [
                        'chat_id' => $chat,
                        'text' => $message,
                        'parse_mode' => 'HTML',
                        'disable_web_page_preview' => true,
                    ];
                    $thread = $tg['thread'] ?? null;
                    if ($thread !== null && (int)$thread > 0) {
                        $params['message_thread_id'] = (int)$thread;
                    }
                    $raw = null; $err = null;
                    $resp = telegram_api('sendMessage', $params, $raw, $err);
                    if (is_array($resp) && !empty($resp['ok'])) {
                        $okForThis++;
                    } else {
                        $errors++;
                        tg_timer_log("send#{$id} chat={$chat} ERROR: ".($err ?: json_encode($raw, JSON_UNESCAPED_UNICODE)));
                    }
                    usleep(120_000);
                }

                if ($okForThis > 0) {
                    foreach ($dueIdx as $i) { $sentMask |= (1 << $i); }
                    // Persist sent_mask + last_sent_date
                    db_exec("UPDATE tg_broadcast_schedules SET sent_mask=?, last_sent_date=? WHERE id=?", [$sentMask, $lastDate, $id]);
                    $sent += $okForThis;
                    $details[] = "sent#$id x{$okForThis}";
                    tg_timer_log("sent#{$id} to={$okForThis} slots=".implode(',', $dueIdx));
                } else {
                    $details[] = "no-targets#$id";
                }
            } catch (Throwable $e) {
                $errors++;
                tg_timer_log("ERROR#$id ".$e->getMessage());
            } finally {
                try { db_col("SELECT RELEASE_LOCK(?)", [$lockKey]); } catch (Throwable $e) {}
            }
        }

        return ['sent'=>$sent,'errors'=>$errors,'details'=>$details];
    }
}
