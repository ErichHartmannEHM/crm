<?php
require_once __DIR__.'/db.php';

function ttch_list_by_team(int $team_id): array {
  return db_all("SELECT * FROM team_telegram_chats WHERE team_id=? ORDER BY id DESC", [$team_id]);
}

function ttch_bind(int $team_id, int $chat_id, string $chat_type='group', ?string $title=null): void {
  db_exec("INSERT INTO team_telegram_chats(team_id,chat_id,chat_type,title,is_active)
           VALUES(?,?,?,?,1)
           ON DUPLICATE KEY UPDATE team_id=VALUES(team_id), chat_type=VALUES(chat_type),
                                   title=VALUES(title), is_active=1",
           [$team_id,$chat_id,$chat_type,$title]);
}

function ttch_unbind(int $team_id, int $chat_id): void {
  db_exec("DELETE FROM team_telegram_chats WHERE team_id=? AND chat_id=?", [$team_id,$chat_id]);
}

function ttch_set_active(int $team_id, int $chat_id, bool $active): void {
  db_exec("UPDATE team_telegram_chats SET is_active=? WHERE team_id=? AND chat_id=?", [$active?1:0,$team_id,$chat_id]);
}

function ttch_get_team_id_by_chat(int $chat_id): ?int {
  $r = db_row("SELECT team_id FROM team_telegram_chats WHERE chat_id=? AND is_active=1", [$chat_id]);
  return $r ? (int)$r['team_id'] : null;
}
