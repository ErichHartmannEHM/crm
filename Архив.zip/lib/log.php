<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

/**
 * Unified audit log storage (plural: audit_logs).
 * This file also migrates legacy `audit_log` table if present.
 */
function audit_bootstrap(): void {
    try {
        // Ensure new canonical table exists
        db_exec("CREATE TABLE IF NOT EXISTS `audit_logs`(
            `id` BIGINT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
            `user_id` BIGINT UNSIGNED NULL,
            `entity_type` VARCHAR(50) NOT NULL,
            `action` VARCHAR(50) NOT NULL,
            `entity_id` BIGINT UNSIGNED NULL,
            `payload_json` JSON NULL,
            `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

        // Migrate from legacy `audit_log` (singular) if it exists and `audit_logs` is empty
        $has_legacy = (int)db_col("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = 'audit_log'") > 0;
        $is_empty   = (int)db_col("SELECT COUNT(*) FROM audit_logs") === 0;

        if ($has_legacy && $is_empty) {
            // best-effort copy with column mapping
            try {
                db_exec("INSERT INTO audit_logs(entity_type, action, entity_id, payload_json, created_at)
                         SELECT entity, action, entity_id, payload, created_at FROM audit_log");
            } catch (Throwable $e) {
                // ignore copy errors
            }
        }
    } catch (Throwable $e) {
        // ignore bootstrap errors
    }
}
audit_bootstrap();

/** Write audit record (best effort) */
function log_op(string $entity_type, string $action, $entity_id = null, array $payload = []): void {
    try {
        db_exec("INSERT INTO `audit_logs`(`entity_type`,`action`,`entity_id`,`payload_json`,`created_at`)
                 VALUES(?,?,?,?,NOW())",
            [$entity_type, $action, $entity_id, json_encode($payload, JSON_UNESCAPED_UNICODE)]);
    } catch (Throwable $e) {
        // swallow
    }
}
