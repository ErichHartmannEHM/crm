<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

function h($s): string { return htmlspecialchars((string)$s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }

function csrf_token(): string {
    if (empty($_SESSION['csrf'])) $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['csrf'];
}
function csrf_field(): string { return '<input type="hidden" name="csrf" value="'.h(csrf_token()).'">'; }
function csrf_check(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $ok = isset($_POST['csrf']) && hash_equals($_SESSION['csrf'] ?? '', (string)$_POST['csrf']);
        if (!$ok) { http_response_code(419); exit('CSRF failed'); }
    }
}

function money_uah($n): string { return number_format((float)$n, 2, '.', ' ').' грн'; }
function money_usd($n): string { return '$'.number_format((float)$n, 2, '.', ''); }

function mask_pan_last4($last4): string {
    $d = preg_replace('/\D/', '', (string)$last4);
    if ($d === '') $d = '????';
    return '**** **** **** '.$d;
}

function card_last4_from_row(array $c): string {
    foreach (['pan_last4','last4','card_last4'] as $k) {
        if (!empty($c[$k])) return substr(preg_replace('/\D/', '', (string)$c[$k]), -4);
    }
    foreach (['card_number','pan','number'] as $k) {
        if (!empty($c[$k])) return substr(preg_replace('/\D/', '', (string)$c[$k]), -4);
    }
    return '????';
}

function bank_label_from_row(array $row): string {
    foreach (['bank','bank_name','bank_type','issuer'] as $k) {
        if (!empty($row[$k])) {
            $v = strtolower((string)$row[$k]);
            if (str_contains($v,'privat')) return 'Приват';
            if (str_contains($v,'mono'))   return 'Моно';
            return ucfirst($v);
        }
    }
    return '—';
}

/**
 * Читаем человеко‑читаемое имя работника из строки карты.
 * Предпочтение: drop_name > drop > name; иначе «—».
 */
function card_drop_from_row(array $row): string {
    foreach (['drop_name','drop','name'] as $k) {
        if (!empty($row[$k])) return (string)$row[$k];
    }
    // Иногда приходит из JOIN-ов:
    if (!empty($row['buyer_name']) && !empty($row['team_name'])) {
        return (string)$row['buyer_name'];
    }
    return '—';
}

