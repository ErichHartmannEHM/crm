<?php
declare(strict_types=1);
require_once __DIR__ . '/settings.php';

function fx_get_usd_uah_rate(): float {
    $v = (float) setting_get('manual_fx', 42.00);
    if ($v <= 0) $v = 42.00;
    return round($v, 4);
}
function fx_set_usd_uah_rate(float $rate): void {
    if ($rate > 0) setting_set('manual_fx', $rate);
}
function fx_uah_to_usd(float $uah): float {
    $r = fx_get_usd_uah_rate();
    return $r > 0 ? round($uah / $r, 2) : 0.0;
}
function fx_usd_to_uah(float $usd): float {
    $r = fx_get_usd_uah_rate();
    return round($usd * $r, 2);
}
