<?php
declare(strict_types=1);

/**
 * Partners & Calculator module (compat v8)
 * - НЕ переопределяет ваши db_*; использует calc_db_*.
 * - При наличии db_all/db_row/db_cell/db_exec вызывает их в СИГНАТУРЕ (SQL, array $params).
 * - Фолбэк: сначала mysqli, потом PDO (если есть). PDO не обязателен.
 * - ensure_partners_schema() не требует PDO.
 * - API для settings.php: teams_all_for_calc(), team_percents_all(), team_percents_save() и алиасы.
 */

// ======================= HELPERS =======================
function calc_params_arr(array $params): array {
    // normalize variadic params into a single array of params
    if (count($params) === 0) return [];
    if (count($params) === 1 && is_array($params[0])) return $params[0];
    return $params;
}

// ======================= CONNECTORS =======================

/** @return mysqli|null */
function calc_mysqli() {
    static $mysqli = null;
    if ($mysqli instanceof mysqli) return $mysqli;

    if (isset($GLOBALS['mysqli']) && $GLOBALS['mysqli'] instanceof mysqli) return $GLOBALS['mysqli'];
    if (isset($GLOBALS['db']) && $GLOBALS['db'] instanceof mysqli) return $GLOBALS['db'];

    // include bootstraps (may define constants or ready connection)
    $candidates = [
        __DIR__ . '/db.php',
        __DIR__ . '/../lib/db.php',
        __DIR__ . '/../config.php',
        __DIR__ . '/config.php',
        __DIR__ . '/../includes/config.php',
        __DIR__ . '/../core/config.php',
        __DIR__ . '/../admin/config.php',
    ];
    foreach ($candidates as $file) {
        if (is_file($file)) {
            require_once $file;
            if (isset($GLOBALS['mysqli']) && $GLOBALS['mysqli'] instanceof mysqli) return $GLOBALS['mysqli'];
            if (isset($GLOBALS['db']) && $GLOBALS['db'] instanceof mysqli) return $GLOBALS['db'];
        }
    }

    $host = defined('DB_HOST') ? DB_HOST : (defined('DB_SERVER') ? DB_SERVER : null);
    $name = defined('DB_NAME') ? DB_NAME : (defined('DATABASE_NAME') ? DATABASE_NAME : null);
    $user = defined('DB_USER') ? DB_USER : (defined('DB_USERNAME') ? DB_USERNAME : null);
    $pass = defined('DB_PASS') ? DB_PASS : (defined('DB_PASSWORD') ? DB_PASSWORD : null);
    $port = defined('DB_PORT') ? DB_PORT : ini_get("mysqli.default_port");
    $charset = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';

    if ($host && $name && $user !== null && function_exists('mysqli_init')) {
        $mysqli = mysqli_init();
        @$mysqli->real_connect($host, $user, $pass, $name, (int)$port);
        if ($mysqli && !$mysqli->connect_errno) {
            @$mysqli->set_charset($charset);
            return $mysqli;
        }
    }
    return null;
}

/** @return PDO|null */
function calc_pdo() {
    static $pdo = null;
    if ($pdo instanceof PDO) return $pdo;

    if (function_exists('pdo')) {
        $maybe = @pdo();
        if ($maybe instanceof PDO) { $pdo = $maybe; return $pdo; }
    }
    if (function_exists('db')) {
        $maybe = @db();
        if ($maybe instanceof PDO) { $pdo = $maybe; return $pdo; }
    }
    if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];

    // include bootstraps (may define constants or pdo)
    $candidates = [
        __DIR__ . '/db.php',
        __DIR__ . '/../lib/db.php',
        __DIR__ . '/../config.php',
        __DIR__ . '/config.php',
        __DIR__ . '/../includes/config.php',
        __DIR__ . '/../core/config.php',
        __DIR__ . '/../admin/config.php',
        __DIR__ . '/../lib/pdo.php',
    ];
    foreach ($candidates as $file) {
        if (is_file($file)) {
            require_once $file;
            if (function_exists('pdo')) {
                $maybe = @pdo();
                if ($maybe instanceof PDO) { $pdo = $maybe; return $pdo; }
            }
            if (isset($GLOBALS['pdo']) && $GLOBALS['pdo'] instanceof PDO) return $GLOBALS['pdo'];
        }
    }

    $host = defined('DB_HOST') ? DB_HOST : (defined('DB_SERVER') ? DB_SERVER : null);
    $name = defined('DB_NAME') ? DB_NAME : (defined('DATABASE_NAME') ? DATABASE_NAME : null);
    $user = defined('DB_USER') ? DB_USER : (defined('DB_USERNAME') ? DB_USERNAME : null);
    $pass = defined('DB_PASS') ? DB_PASS : (defined('DB_PASSWORD') ? DB_PASSWORD : null);
    $charset = defined('DB_CHARSET') ? DB_CHARSET : 'utf8mb4';

    if ($host && $name && $user !== null) {
        try {
            $dsn = "mysql:host={$host};dbname={$name};charset={$charset}";
            $attr = [PDO::ATTR_ERRMODE=>PDO::ERRMODE_EXCEPTION, PDO::ATTR_DEFAULT_FETCH_MODE=>PDO::FETCH_ASSOC];
            $pdo = new PDO($dsn, $user, $pass, $attr);
            return $pdo;
        } catch (Throwable $e) {
            return null;
        }
    }
    return null;
}

// ======================= DB WRAPPERS =======================

function calc_db_all(string $sql, ...$params): array {
    $arr = calc_params_arr($params);
    if (function_exists('db_all')) return db_all($sql, $arr);

    // mysqli
    $mysqli = calc_mysqli();
    if ($mysqli instanceof mysqli) {
        $rows = calc_mysqli_all($mysqli, $sql, $arr);
        if ($rows !== null) return $rows;
    }

    // pdo
    $pdo = calc_pdo();
    if ($pdo instanceof PDO) {
        $st = $pdo->prepare($sql);
        $st->execute($arr);
        return $st->fetchAll(PDO::FETCH_ASSOC);
    }
    return [];
}

function calc_db_row(string $sql, ...$params): ?array {
    $rows = calc_db_all($sql, ...$params);
    return $rows ? $rows[0] : null;
}

function calc_db_cell(string $sql, ...$params) {
    $row = calc_db_row($sql, ...$params);
    if (!$row) return null;
    return array_shift($row);
}

function calc_db_exec(string $sql, ...$params) {
    $arr = calc_params_arr($params);
    if (function_exists('db_exec')) {
        $ret = db_exec($sql, $arr);
        if ($ret instanceof PDOStatement) return true;
        if (is_bool($ret)) return $ret;
        if (is_int($ret)) return $ret >= 0;
        return $ret ? true : false;
    }

    // mysqli
    $mysqli = calc_mysqli();
    if ($mysqli instanceof mysqli) {
        $ok = calc_mysqli_exec($mysqli, $sql, $arr);
        if ($ok !== null) return $ok;
    }

    // pdo
    $pdo = calc_pdo();
    if ($pdo instanceof PDO) {
        $st = $pdo->prepare($sql);
        $ok = $st->execute($arr);
        return $ok ? true : false;
    }
    return false;
}

// ---------- mysqli helpers ----------

/** @return bool|null */
function calc_mysqli_exec(mysqli $mysqli, string $sql, array $params) {
    if (!$params || strpos($sql, '?') === false) {
        $res = @$mysqli->query($sql);
        if ($res === true) return true;
        if ($res instanceof mysqli_result) { $res->free(); return true; }
        return false;
    }
    $stmt = @$mysqli->prepare($sql);
    if (!$stmt) {
        $qi = calc_mysqli_interpolate($mysqli, $sql, $params);
        $res = @$mysqli->query($qi);
        if ($res === true) return true;
        if ($res instanceof mysqli_result) { $res->free(); return true; }
        return false;
    }
    $types = ''; $bind = [];
    foreach ($params as $v) {
        if (is_int($v))       { $types .= 'i'; $bind[] = $v; }
        elseif (is_float($v)) { $types .= 'd'; $bind[] = $v; }
        elseif (is_null($v))  { $types .= 's'; $bind[] = null; }
        else                  { $types .= 's'; $bind[] = (string)$v; }
    }
    $stmt->bind_param($types, ...$bind);
    $ok = @$stmt->execute();
    $stmt->close();
    return $ok ? true : false;
}

/** @return array<int, array>|null */
function calc_mysqli_all(mysqli $mysqli, string $sql, array $params) {
    if (!$params || strpos($sql, '?') === false) {
        $res = @$mysqli->query($sql);
        if ($res === false) return [];
        $rows = [];
        while ($row = $res->fetch_assoc()) { $rows[] = $row; }
        $res->free();
        return $rows;
    }
    $stmt = @$mysqli->prepare($sql);
    if (!$stmt) {
        $qi = calc_mysqli_interpolate($mysqli, $sql, $params);
        $res = @$mysqli->query($qi);
        if ($res === false) return [];
        $rows = [];
        while ($row = $res->fetch_assoc()) { $rows[] = $row; }
        $res->free();
        return $rows;
    }
    $types = ''; $bind = [];
    foreach ($params as $v) {
        if (is_int($v))       { $types .= 'i'; $bind[] = $v; }
        elseif (is_float($v)) { $types .= 'd'; $bind[] = $v; }
        elseif (is_null($v))  { $types .= 's'; $bind[] = null; }
        else                  { $types .= 's'; $bind[] = (string)$v; }
    }
    $stmt->bind_param($types, ...$bind);
    $ok = @$stmt->execute();
    if (!$ok) { $stmt->close(); return []; }
    if (method_exists($stmt, 'get_result')) {
        $res = $stmt->get_result();
        $rows = $res ? $res->fetch_all(MYSQLI_ASSOC) : [];
        if ($res) $res->free();
        $stmt->close();
        return $rows;
    }
    $meta = $stmt->result_metadata();
    if (!$meta) { $stmt->close(); return []; }
    $fields = []; $rowbind = []; $bindrefs = [];
    while ($field = $meta->fetch_field()) { $fields[] = $field->name; $rowbind[] = null; $bindrefs[] = &$rowbind[count($rowbind)-1]; }
    call_user_func_array([$stmt, 'bind_result'], $bindrefs);
    $rows = [];
    while ($stmt->fetch()) {
        $row = [];
        foreach ($fields as $idx => $name) { $row[$name] = $rowbind[$idx]; }
        $rows[] = $row;
    }
    $stmt->close();
    return $rows;
}

function calc_mysqli_interpolate(mysqli $mysqli, string $sql, array $params): string {
    $parts = explode('?', $sql);
    $out = '';
    foreach ($parts as $i=>$part) {
        $out .= $part;
        if ($i < count($params)) {
            $v = $params[$i];
            if (is_int($v) || is_float($v)) { $out .= (string)$v; }
            elseif (is_null($v))            { $out .= "NULL"; }
            else                            { $out .= "'" . $mysqli->real_escape_string((string)$v) . "'"; }
        }
    }
    return $out;
}

// ======================= SCHEMA & API =======================



/**
 * Check if a column exists in a table (robust, cached).
 */
function calc_column_exists(string $table, string $column): bool {
    static $cache = [];
    $key = $table.'|'.$column;
    if (isset($cache[$key])) return $cache[$key] === true;

    // Use INFORMATION_SCHEMA (works well with prepared statements).
    try {
        $row = calc_db_row(
            "SELECT COUNT(*) AS cnt
               FROM INFORMATION_SCHEMA.COLUMNS
              WHERE TABLE_SCHEMA = DATABASE()
                AND TABLE_NAME = ?
                AND COLUMN_NAME = ?
              LIMIT 1",
            [$table, $column]
        );
        if (is_array($row)) {
            $ok = (int)($row['cnt'] ?? 0) > 0;
            $cache[$key] = $ok ? true : false;
            if ($ok) return true;
        }
    } catch (Throwable $e) {
        // ignore and try fallback
    }

    // Fallback: SHOW COLUMNS (cannot be parameterized in some drivers)
    // Allow only safe identifiers to avoid SQL injection.
    if (!preg_match('~^[A-Za-z0-9_]+$~', $table) || !preg_match('~^[A-Za-z0-9_]+$~', $column)) {
        $cache[$key] = false;
        return false;
    }
    try {
        $row = calc_db_row("SHOW COLUMNS FROM `{$table}` LIKE '{$column}'");
        $ok = is_array($row) && !empty($row);
        $cache[$key] = $ok ? true : false;
        return $ok;
    } catch (Throwable $e) {
        $cache[$key] = false;
        return false;
    }
}function ensure_partners_schema(): void {
    calc_db_exec("CREATE TABLE IF NOT EXISTS partners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(128) NOT NULL UNIQUE,
        percent DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        is_active TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    // New columns for partner kind and Telegram chat
    if (!calc_column_exists('partners', 'type')) {
        try { calc_db_exec("ALTER TABLE partners ADD COLUMN `type` ENUM('worker','team') NOT NULL DEFAULT 'worker' AFTER is_active"); } catch (Throwable $e) { /* ignore */ }
    }
    if (!calc_column_exists('partners', 'tg_chat_id')) {
        try { calc_db_exec("ALTER TABLE partners ADD COLUMN `tg_chat_id` VARCHAR(64) NULL DEFAULT NULL AFTER `type`"); } catch (Throwable $e) { /* ignore */ }
    }

    calc_db_exec("CREATE TABLE IF NOT EXISTS drop_partners (
        id INT AUTO_INCREMENT PRIMARY KEY,
        drop_id INT NOT NULL,
        partner_id INT NOT NULL,
        created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_drop_partner (drop_id, partner_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

    calc_db_exec("CREATE TABLE IF NOT EXISTS team_calc_percents (
        team_id INT PRIMARY KEY,
        percent DECIMAL(10,2) NOT NULL DEFAULT 0.00,
        updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");
    calc_db_exec("CREATE TABLE IF NOT EXISTS team_partner_map (
        team_id INT PRIMARY KEY,
        partner_id INT NOT NULL,
        percent DECIMAL(10,2) NULL DEFAULT NULL,
        updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        CONSTRAINT fk_team_partner_map_partner FOREIGN KEY (partner_id) REFERENCES partners(id) ON DELETE RESTRICT
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");


    _ensure_default_partner('EHM', 25.0);
    _ensure_default_partner('Parfumer', 25.0);
}

function _ensure_default_partner(string $name, float $percent): void {
    $id = calc_db_cell("SELECT id FROM partners WHERE name = ?", [$name]);
    if (!$id) {
        calc_db_exec("INSERT INTO partners (name, percent, is_active) VALUES (?, ?, 1)", [$name, $percent]);
    }
}

// Backward-compat alias
if (!function_exists('calc_bootstrap_schema')) {
    function calc_bootstrap_schema(): void { ensure_partners_schema(); }
}

// ---------- Partners CRUD ----------

function partners_all(bool $include_inactive=false, ?string $type=null): array {
    ensure_partners_schema();
    $cols = "id, name, percent, is_active";
    if (calc_column_exists('partners', 'type'))      { $cols .= ", type"; }
    if (calc_column_exists('partners', 'tg_chat_id')){ $cols .= ", tg_chat_id"; }
    $sql = "SELECT " . $cols . " FROM partners WHERE 1";
    $params = [];
    if (!$include_inactive) { $sql .= " AND is_active=1"; }
    if ($type !== null && in_array($type, ['worker','team'], true) && calc_column_exists('partners','type')) {
        $sql .= " AND type = ?";
        $params[] = $type;
    }
    $sql .= " ORDER BY name ASC";
    return calc_db_all($sql, $params);
}


function partner_create(string $name, float $percent, bool $active=true, ?string $type=null, ?string $tg_chat_id=null): int {
    ensure_partners_schema();
    $cols = "name, percent, is_active";
    $vals = "?, ?, ?";
    $params = [$name, $percent, $active ? 1 : 0];
    if (calc_column_exists('partners','type')) {
        $cols .= ", type";
        $vals .= ", ?";
        $params[] = $type ?? 'worker';
    }
    if (calc_column_exists('partners','tg_chat_id')) {
        $cols .= ", tg_chat_id";
        $vals .= ", ?";
        $params[] = $tg_chat_id;
    }
    calc_db_exec("INSERT INTO partners ($cols) VALUES ($vals)", $params);
    return (int) calc_db_cell("SELECT id FROM partners WHERE name = ?", [$name]);
}



function partner_update(int $id, string $name, float $percent, bool $active, ?string $type=null, ?string $tg_chat_id=null): void {
    ensure_partners_schema();
    $set = "name=?, percent=?, is_active=?";
    $params = [$name, $percent, $active ? 1 : 0];

    // Update 'type' only if 5th arg was passed
    if (calc_column_exists('partners','type') && func_num_args() >= 5) {
        $set .= ", type=?";
        $params[] = $type;
    }
    // Update 'tg_chat_id' only if 6th arg was passed (to avoid wiping it when old code calls with 4 args)
    if (calc_column_exists('partners','tg_chat_id') && func_num_args() >= 6) {
        $set .= ", tg_chat_id=?";
        $params[] = $tg_chat_id;
    }
    $params[] = $id;
    calc_db_exec("UPDATE partners SET $set WHERE id=?", $params);
}



function partner_delete(int $id): void {
    calc_db_exec("DELETE FROM drop_partners WHERE partner_id=?", [$id]);
    calc_db_exec("DELETE FROM partners WHERE id=?", [$id]);
}


// ---------- Partner telegram helpers ----------

/** Set or clear Telegram Chat ID for a partner. */
function partner_set_chat_id(int $partner_id, ?string $tg_chat_id): void {
    ensure_partners_schema();
    if (!calc_column_exists('partners','tg_chat_id')) return;
    if ($tg_chat_id === null || $tg_chat_id === '') {
        calc_db_exec("UPDATE partners SET tg_chat_id=NULL WHERE id=?", [$partner_id]);
    } else {
        calc_db_exec("UPDATE partners SET tg_chat_id=? WHERE id=?", [$tg_chat_id, $partner_id]);
    }
}

/** Fetch a single partner by id (including tg_chat_id if present). */
function partner_by_id(int $id): ?array {
    ensure_partners_schema();
    $cols = "id, name, percent, is_active";
    if (calc_column_exists('partners','type'))      { $cols .= ", type"; }
    if (calc_column_exists('partners','tg_chat_id')){ $cols .= ", tg_chat_id"; }
    $row = calc_db_row("SELECT {$cols} FROM partners WHERE id=? LIMIT 1", [$id]);
    return $row ?: null;
}
// ---------- Drop <-> partners mapping ----------

function drop_partner_ids(int $drop_id): array {
    $rows = calc_db_all("SELECT partner_id FROM drop_partners WHERE drop_id=?", [$drop_id]);
    return array_map(fn($r) => (int)$r['partner_id'], $rows);
}

function drop_partners_save(int $drop_id, array $partner_ids): void {
    $partner_ids = array_values(array_unique(array_map('intval', $partner_ids)));
    calc_db_exec("DELETE FROM drop_partners WHERE drop_id=?", [$drop_id]);
    foreach ($partner_ids as $pid) {
        calc_db_exec("INSERT IGNORE INTO drop_partners (drop_id, partner_id) VALUES (?, ?)", [$drop_id, $pid]);
    }
}

function drop_partners_effective(int $drop_id): array {
    $rows = calc_db_all("SELECT p.id, p.name, p.percent
                    FROM partners p
                    INNER JOIN drop_partners dp ON dp.partner_id = p.id
                    WHERE dp.drop_id=? AND p.is_active=1
                    ORDER BY p.name ASC", [$drop_id]);
    if ($rows && count($rows) > 0) return $rows;

    $fallback = calc_db_all("SELECT id, name, percent FROM partners WHERE name IN ('EHM','Parfumer') AND is_active=1 ORDER BY name ASC");
    return $fallback;
}

// ---------- Teams handling ----------

function calc_fetch_teams(): array {
    $tries = [
        "SELECT id, name FROM teams ORDER BY name ASC",
        "SELECT id, title AS name FROM teams ORDER BY title ASC",
        "SELECT id, team_name AS name FROM teams ORDER BY team_name ASC",
    ];
    foreach ($tries as $sql) {
        try {
            $rows = calc_db_all($sql);
            if (is_array($rows) && count($rows)) return $rows;
        } catch (Throwable $e) { /* continue */ }
    }
    return [];
}

if (!function_exists('teams_all_for_calc')) {
    function teams_all_for_calc(): array { return calc_fetch_teams(); }
}

if (!function_exists('team_percents_all')) {
    function team_percents_all(): array {
        ensure_partners_schema();
        $rows = calc_db_all("SELECT team_id, percent FROM team_calc_percents ORDER BY team_id ASC");
        foreach ($rows as &$r) { $r['team_id'] = (int)$r['team_id']; $r['percent'] = (float)$r['percent']; }
        return $rows;
    }
}

if (!function_exists('team_percents_save')) {
    function team_percents_save(array $data): void {
        ensure_partners_schema();
        $items = [];
        if ($data === []) return;
        $isAssocMap = array_keys($data) !== range(0, count($data)-1);
        if ($isAssocMap) {
            foreach ($data as $tid=>$pc) { $tid=(int)$tid; $pc=(float)$pc; if ($tid>0) $items[]=['team_id'=>$tid,'percent'=>$pc]; }
        } else {
            foreach ($data as $row) {
                if (!is_array($row)) continue;
                $tid = isset($row['team_id']) ? (int)$row['team_id'] : (isset($row[0]) ? (int)$row[0] : 0);
                $pc  = isset($row['percent']) ? (float)$row['percent'] : (isset($row[1]) ? (float)$row[1] : 0.0);
                if ($tid>0) $items[] = ['team_id'=>$tid, 'percent'=>$pc];
            }
        }
        foreach ($items as $it) {
            calc_db_exec("INSERT INTO team_calc_percents (team_id, percent) VALUES (?, ?)
                          ON DUPLICATE KEY UPDATE percent=VALUES(percent), updated_at=CURRENT_TIMESTAMP",
                         [$it['team_id'], $it['percent']]);
        }
    }
}

// Алиасы
if (!function_exists('teams_percents_all')) { function teams_percents_all(): array { return team_percents_all(); } }
if (!function_exists('teams_percent_all'))  { function teams_percent_all(): array  { return team_percents_all(); } }
if (!function_exists('team_percent_map'))   { function team_percent_map(): array   {
    $rows = team_percents_all(); $map=[]; foreach($rows as $r){ $map[(int)$r['team_id']] = (float)$r['percent']; } return $map;
}}
if (!function_exists('team_percent_get')) {
    function team_percent_get(?int $team_id): float {
        if (!$team_id) return 0.0;
        $v = calc_db_cell("SELECT percent FROM team_calc_percents WHERE team_id=?", [$team_id]);
        return $v !== false && $v !== null ? (float)$v : 0.0;
    }
}
if (!function_exists('team_percent_set')) {
    function team_percent_set(int $team_id, float $percent): void {
        calc_db_exec("INSERT INTO team_calc_percents (team_id, percent) VALUES (?, ?)
                      ON DUPLICATE KEY UPDATE percent=VALUES(percent), updated_at=CURRENT_TIMESTAMP",
                      [$team_id, $percent]);
    }
}

// ---------- Drops (workers) fetcher ----------

function calc_fetch_drops(): array {
    $tries = [
        "SELECT id, name, tg_nick FROM drops ORDER BY name ASC",
        "SELECT id, name, telegram AS tg_nick FROM drops ORDER BY name ASC",
        "SELECT id, name, tg AS tg_nick FROM drops ORDER BY name ASC",
        "SELECT id, fio AS name, tg AS tg_nick FROM drops ORDER BY fio ASC",
        "SELECT id, fio AS name, telegram AS tg_nick FROM drops ORDER BY fio ASC",
        "SELECT id, full_name AS name, telegram AS tg_nick FROM drops ORDER BY full_name ASC",
    ];
    foreach ($tries as $sql) {
        try {
            $rows = calc_db_all($sql);
            if (is_array($rows) && count($rows)) return $rows;
        } catch (Throwable $e) { /* next */ }
    }
    return [];
}

// ---------- Calculator ----------


// ---------- Team partner mapping ----------
if (!function_exists('team_partner_map_all')) {
    function team_partner_map_all(): array {
        ensure_partners_schema();
        $rows = calc_db_all("
            SELECT m.team_id, m.partner_id, m.percent, p.name AS partner_name, p.percent AS default_percent
              FROM team_partner_map m
              LEFT JOIN partners p ON p.id = m.partner_id
            ORDER BY m.team_id ASC
        ");
        $map = [];
        foreach ($rows as $r) {
            $tid = (int)($r['team_id'] ?? 0);
            if ($tid<=0) continue;
            $map[$tid] = [
                'team_id'        => $tid,
                'partner_id'     => isset($r['partner_id']) ? (int)$r['partner_id'] : null,
                'percent'        => isset($r['percent']) ? ($r['percent'] !== null ? (float)$r['percent'] : null) : null,
                'partner_name'   => isset($r['partner_name']) ? (string)$r['partner_name'] : null,
                'default_percent'=> isset($r['default_percent']) ? (float)$r['default_percent'] : null,
            ];
        }
        return $map;
    }
}
if (!function_exists('team_partner_get')) {
    function team_partner_get(?int $team_id): ?array {
        if (!$team_id) return null;
        ensure_partners_schema();
        $row = calc_db_row("
            SELECT m.team_id, m.partner_id, COALESCE(m.percent, p.percent) AS percent, p.name
              FROM team_partner_map m
              JOIN partners p ON p.id = m.partner_id
             WHERE m.team_id = ?
             LIMIT 1
        ", [$team_id]);
        if (!$row) return null;
        return [
            'team_id' => (int)$row['team_id'],
            'id'      => (int)$row['partner_id'],
            'name'    => (string)$row['name'],
            'percent' => (float)$row['percent'],
        ];
    }
}
if (!function_exists('team_partner_set')) {
    function team_partner_set(int $team_id, ?int $partner_id, ?float $percent): void {
        ensure_partners_schema();
        if (!$partner_id) {
            // remove mapping
            calc_db_exec("DELETE FROM team_partner_map WHERE team_id=?", [$team_id]);
            return;
        }
        // Upsert
        calc_db_exec("INSERT INTO team_partner_map (team_id, partner_id, percent) VALUES (?, ?, ?)
                      ON DUPLICATE KEY UPDATE partner_id=VALUES(partner_id), percent=VALUES(percent), updated_at=CURRENT_TIMESTAMP",
                      [$team_id, $partner_id, $percent !== null ? $percent : null]);
    }
}
function calculator_compute(int $drop_id, ?int $team_id, float $amount): array {
    ensure_partners_schema();
    $partners = drop_partners_effective($drop_id);
    $lines = [];
    $partners_total = 0.0;
    foreach ($partners as $p) {
        $pc = (float)$p['percent'];
        $amt = round($amount * $pc / 100.0, 2);
        $lines[] = ['id'=>(int)$p['id'], 'name'=>(string)$p['name'], 'percent'=>$pc, 'amount'=>$amt];
        $partners_total += $amt;
    }
    
    // Team-level partner (if assigned)
    $tp = team_partner_get($team_id);
    if ($tp) {
        $pc = (float)$tp['percent'];
        $amt = round($amount * $pc / 100.0, 2);
        $lines[] = ['id'=>(int)$tp['id'], 'name'=>(string)$tp['name'].' (команда)', 'percent'=>$pc, 'amount'=>$amt];
        $partners_total += $amt;
    }
$team_percent = team_percent_get($team_id);
    $team_amount  = round($amount * $team_percent / 100.0, 2);
    $worker_income = round($amount - $partners_total - $team_amount, 2);
    return [
        'partners'       => $lines,
        'partners_total' => round($partners_total, 2),
        'team_percent'   => $team_percent,
        'team_amount'    => $team_amount,
        'worker_income'  => $worker_income,
    ];
}

// ---------- Helpers ----------

function fmt_money(float $n): string {
    return number_format($n, 2, ',', ' ');
}