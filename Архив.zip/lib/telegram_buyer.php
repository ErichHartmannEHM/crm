<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

/** Resolve buyer-bot token/admin chat (admin chat only for tests/alerts) */
function _tg_buyer_resolve_bot_token(): ?string {
  try {
    $cfg = app_config();
    if (!empty($cfg['telegram_buyer']['bot_token'])) return (string)$cfg['telegram_buyer']['bot_token'];
  } catch (Throwable $e) {}
  $env = getenv('TG_BOT_TOKEN_BUYER'); if ($env) return (string)$env;
  $set = setting_get('telegram_buyer_bot_token', null); if ($set) return (string)$set;
  return null;
}
function _tg_buyer_resolve_admin_chat(): ?string {
  try {
    $cfg = app_config();
    if (!empty($cfg['telegram']['admin_chat_id'])) return (string)$cfg['telegram']['admin_chat_id']; // reuse main admin for alerts
    if (!empty($cfg['security']['telegram_admin_chat_id'])) return (string)$cfg['security']['telegram_admin_chat_id'];
  } catch (Throwable $e) {}
  $env = getenv('TG_ADMIN_CHAT_ID'); if ($env) return (string)$env;
  return null;
}
function _tg_buyer_mask_token(?string $t): string {
  if (!$t) return '(empty)';
  $len = strlen($t); return $len<=10?str_repeat('*',$len):substr($t,0,6).'...'.substr($t,-4);
}

/** Generic Telegram API call (JSON) for buyer bot */
function telegram_buyer_api(string $method, array $params = [], ?array &$raw = null, ?string &$error = null): ?array {
  $error = null; $raw = null;
  $token = _tg_buyer_resolve_bot_token();
  if (!$token) { $error = 'No buyer bot token'; return null; }
  if (!function_exists('curl_init')) { $error = 'cURL not available'; return null; }
  $url = "https://api.telegram.org/bot{$token}/".$method;
  $ch = curl_init($url);
  curl_setopt_array($ch,[
    CURLOPT_RETURNTRANSFER=>true, CURLOPT_POST=>true,
    CURLOPT_HTTPHEADER=>['Content-Type: application/json'],
    CURLOPT_POSTFIELDS=>json_encode($params, JSON_UNESCAPED_UNICODE),
    CURLOPT_CONNECTTIMEOUT=>8, CURLOPT_TIMEOUT=>20,
  ]);
  $resp = curl_exec($ch); $err = curl_error($ch); $code = curl_getinfo($ch, CURLINFO_HTTP_CODE); curl_close($ch);
  $j = json_decode((string)$resp, true);
  if (!is_array($j)) { $error = "HTTP {$code}: ".($resp?:$err?:'empty'); return null; }
  if (empty($j['ok'])) { $error = "TG error ".($j['error_code']??$code).": ".($j['description']??''); }
  $raw = $j; return $j;
}
function telegram_buyer_send(string $chat_id, string $text, ?string &$error = null): bool {
  $error = null; $raw = null;
  $j = telegram_buyer_api('sendMessage', ['chat_id'=>$chat_id,'text'=>$text,'parse_mode'=>'HTML','disable_web_page_preview'=>true], $raw, $error);
  return is_array($j) && !empty($j['ok']);
}
function telegram_buyer_send_document(string $chat_id, string $file_path, string $caption = '', ?string &$error = null): bool {
  $error = null; $raw = null;
  $token = _tg_buyer_resolve_bot_token();
  if (!$token) { $error = 'No buyer bot token'; return false; }
  $url = "https://api.telegram.org/bot{$token}/sendDocument";
  $post = [
    'chat_id' => $chat_id,
    'caption' => $caption,
    'parse_mode' => 'HTML',
  ];
  if (!is_file($file_path)) { $error = 'file not found'; return false; }
  $post['document'] = new CURLFile($file_path, 'text/csv', basename($file_path));
  $ch = curl_init($url);
  curl_setopt_array($ch, [
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => $post,
    CURLOPT_CONNECTTIMEOUT => 6,
    CURLOPT_TIMEOUT => 20,
  ]);
  $resp = curl_exec($ch);
  if ($resp === false) { $error = 'cURL: '.curl_error($ch); curl_close($ch); return false; }
  $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
  curl_close($ch);
  $j = json_decode((string)$resp, true);
  if (!is_array($j) || empty($j['ok'])) { $error = 'TG error '.($j['error_code']??$code).': '.($j['description']??''); return false; }
  return true;
}
