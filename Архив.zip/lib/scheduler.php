<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';

function has_col(PDO $pdo, string $table, string $col): bool {
  try {
    $st = $pdo->prepare("SELECT 1 FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=? LIMIT 1");
    $st->execute([$table,$col]); return (bool)$st->fetchColumn();
  } catch (Throwable $e) { return false; }
}
function statuses_inwork(): array {
  return ['in_work','inwork','in work','work','в работе','в роботе','вроботе','у роботі','в роботі'];
}
function statuses_waiting(): array {
  return ['waiting','pending','ожидание','ожиданні','в ожидании','очікування','в очікуванні','очiкування','на ожидании','на очікуванні'];
}
function app_timezone(PDO $pdo): DateTimeZone {
  $tz = null;
  try { $tz = db_col("SELECT `val` FROM `settings` WHERE `k` IN ('alerts.timezone','app.timezone','timezone') ORDER BY `k` LIMIT 1"); } catch (Throwable $e) {}
  if (!$tz) { try { return new DateTimeZone('Europe/Kyiv'); } catch (Throwable $e) { return new DateTimeZone('Europe/Kiev'); } }
  try { return new DateTimeZone((string)$tz); } catch (Throwable $e) { try { return new DateTimeZone('Europe/Kyiv'); } catch (Throwable $e2) { return new DateTimeZone('Europe/Kiev'); } }
}
function weekday_allowed(int $mask, int $weekday1_7): bool {
  if ($mask === 0) return true;
  $bit = 1 << ($weekday1_7 - 1);
  return (($mask & $bit) !== 0);
}

/** Получатели по таймеру (для scope drop/team); only_inwork уважает статусы карт */
function recipients_for_schedule(PDO $pdo, array $sch): array {
  $scope = (string)($sch['scope'] ?? 'drop');
  $only  = (int)($sch['only_inwork'] ?? 0) === 1;

  if ($scope === 'team') {
    // Обычно у команд нет прямой связи с картами; шлём всем активным
    $sql = "SELECT DISTINCT chat_id FROM team_telegram_chats WHERE is_active=1";
    if (has_col($pdo,'team_telegram_chats','active')) $sql .= " AND active=1";
    $rows = db_all($sql);
    $out = []; foreach ($rows as $r) { if (!$r['chat_id']) continue; $out[] = ['chat_id'=>(string)$r['chat_id'],'thread'=>null]; }
    return $out;
  }

  // scope = drop
  $hasThread = has_col($pdo,'drop_telegram_chats','thread_id');
  $selThread = $hasThread ? "dtc.thread_id" : "NULL AS thread_id";
  if ($only) {
    $ph = implode(',', array_fill(0, count(statuses_inwork()), '?'));
    $sql = "SELECT DISTINCT dtc.chat_id, $selThread
            FROM drop_telegram_chats dtc
            JOIN drops d ON d.id=dtc.drop_id
            JOIN cards c ON (c.drop_id=d.id OR (c.drop_name IS NOT NULL AND c.drop_name=d.name))
            WHERE dtc.is_active=1";
    if (has_col($pdo,'drop_telegram_chats','active')) $sql .= " AND dtc.active=1";
    $sql .= " AND c.status IN ($ph)";
    $st = db_exec($sql, statuses_inwork());
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
  } else {
    $sql = "SELECT DISTINCT chat_id, $selThread FROM drop_telegram_chats WHERE is_active=1";
    if (has_col($pdo,'drop_telegram_chats','active')) $sql .= " AND active=1";
    $rows = db_all($sql);
  }
  $out=[]; foreach ($rows as $r) { if(!$r['chat_id']) continue;
    $thread = (isset($r['thread_id']) && $r['thread_id']!==null && $r['thread_id']!=='' && (int)$r['thread_id']>0) ? (int)$r['thread_id'] : null;
    $out[] = ['chat_id'=>(string)$r['chat_id'], 'thread'=>$thread];
  }
  return $out;
}
