<?php
declare(strict_types=1);
require_once __DIR__.'/db.php';
require_once __DIR__.'/telegram.php';

/**
 * Send a message to all active chats bound to the given team.
 */
function notify_team(int $team_id, string $text, ?array $reply_markup=null, string $parse_mode='HTML'): void {
    $token = _tg_resolve_bot_token();
    if (!$token) return;

    // Collect chats
    $rows = db_all("SELECT chat_id FROM team_telegram_chats WHERE team_id=? AND is_active=1", [$team_id]);

    foreach ($rows as $r) {
        $chat_id = $r['chat_id'];
        $params = ['chat_id'=>$chat_id,'text'=>$text,'disable_web_page_preview'=>true];
        if ($parse_mode)   $params['parse_mode'] = $parse_mode;
        if ($reply_markup) $params['reply_markup'] = json_encode($reply_markup, JSON_UNESCAPED_UNICODE);

        telegram_api('sendMessage', $params, $raw, $err);
        // TODO: при желании логировать ошибки
    }
}
