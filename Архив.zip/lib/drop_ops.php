<?php
declare(strict_types=1);

require_once __DIR__.'/db.php';

/* Helpers for schema */
function _tbl_exists(string $t): bool {
  try {
    return (int)db_exec("SELECT COUNT(*) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = ?", [$t])->fetchColumn() > 0;
  } catch (Throwable $e) { return false; }
}
function _col_exists(string $t, string $c): bool {
  try {
    return (int)db_exec("SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = ? AND column_name = ?", [$t,$c])->fetchColumn() > 0;
  } catch (Throwable $e) { return false; }
}

/** Вставка операции работником + зеркалирование (опционально) в payments + пересчёт баланса */
function drop_op_add(int $drop_id, int $card_id, string $type, float $amount_uah, string $source='bot', ?int $created_by=null, ?string $note=null): bool {
  $type = in_array($type, ['topup','debit','hold'], true) ? $type : 'debit';
  $amount_uah = round(max($amount_uah, 0), 2);

  // Денормализация buyer_id и team_id из карты
  $owner = db_exec("SELECT b.id buyer_id, b.team_id team_id FROM cards c JOIN buyers b ON b.id=c.buyer_id WHERE c.id=? LIMIT 1", [$card_id])->fetch(PDO::FETCH_ASSOC);
  $buyer_id = $owner['buyer_id'] ?? null;
  $team_id  = $owner['team_id']  ?? null;

  try {
    db_exec("INSERT INTO drop_ops(drop_id,card_id,buyer_id,team_id,type,amount_uah,note,source,created_by,created_at)
             VALUES(?,?,?,?,?,?,?,?,?,NOW())",
            [$drop_id,$card_id,$buyer_id,$team_id,$type,$amount_uah,$note,$source,$created_by]);

    // Зеркалим при наличии payments
    if (_tbl_exists('payments')) {
      $fields = ['card_id','type','created_at'];
      $vals   = [$card_id,$type,date('Y-m-d H:i:s')];

      if (_col_exists('payments','amount_uah')) { $fields[]='amount_uah'; $vals[]=$amount_uah; }
      elseif (_col_exists('payments','amount')) { $fields[]='amount';     $vals[]=$amount_uah; }

      if (_col_exists('payments','currency')) { $fields[]='currency'; $vals[]='UAH'; }
      if (_col_exists('payments','buyer_id')) { $fields[]='buyer_id'; $vals[]=$buyer_id; }
      if (_col_exists('payments','source'))   { $fields[]='source';   $vals[]='dropbot'; }

      $sql="INSERT INTO payments(".implode(',',array_map(fn($f)=>"`$f`",$fields)).") VALUES (".implode(',',array_fill(0,count($fields),'?')).")";
      @db_exec($sql,$vals);
    }

    // Пересчитать баланс карты
    drop_card_recalc_balance($card_id);
    @require_once __DIR__.'/tg_alerts.php';
    try { tg_alerts_fire_immediate($card_id, null, null); } catch (Throwable $e) {}
    return true;
  } catch (Throwable $e) {
    return false;
  }
}

/** Пересчёт баланса карты по drop_ops (fallback — по payments) */
function drop_card_recalc_balance(int $card_id): void {
  try {
    if (_tbl_exists('drop_ops')) {
      $sum = (float)db_exec("
        SELECT COALESCE(SUM(CASE type WHEN 'topup' THEN amount_uah
                                      WHEN 'debit' THEN -amount_uah
                                      ELSE 0 END),0)
        FROM drop_ops WHERE card_id=?", [$card_id])->fetchColumn();
    } elseif (_tbl_exists('payments')) {
      $a = _col_exists('payments','amount_uah') ? 'amount_uah' : 'amount';
      $sum = (float)db_exec("
        SELECT COALESCE(SUM(CASE type WHEN 'topup' THEN `$a`
                                      WHEN 'debit' THEN -`$a`
                                      ELSE 0 END),0)
        FROM payments WHERE card_id=?", [$card_id])->fetchColumn();
    } else return;

    $balcol = _col_exists('cards','balance_uah') ? 'balance_uah' : (_col_exists('cards','balance') ? 'balance' : null);
    if ($balcol) db_exec("UPDATE cards SET `$balcol`=? WHERE id=?", [round($sum,2), $card_id]);
  } catch (Throwable $e) {}
}

/** Последние операции по команде (через drop_ops; fallback — payments/transactions) */
function drop_ops_last_by_team(int $team_id, int $limit=20): array {
  $limit = max(1, min(100, $limit));
  if (_tbl_exists('drop_ops')) {
    return db_exec("SELECT created_at, type, amount_uah AS amt, 'UAH' AS ccy, card_id FROM drop_ops WHERE team_id=? ORDER BY created_at DESC LIMIT $limit", [$team_id])->fetchAll(PDO::FETCH_ASSOC);
  }
  if (_tbl_exists('payments')) {
    $a=_col_exists('payments','amount_uah')?'amount_uah':'amount'; $c=_col_exists('payments','currency')?'currency':"'UAH'";
    return db_exec("SELECT p.created_at, p.type, p.`$a` AS amt, $c AS ccy, p.card_id FROM payments p JOIN cards c ON c.id=p.card_id JOIN buyers b ON b.id=c.buyer_id WHERE b.team_id=? ORDER BY p.created_at DESC LIMIT $limit", [$team_id])->fetchAll(PDO::FETCH_ASSOC);
  }
  if (_tbl_exists('transactions')) {
    $a=_col_exists('transactions','amount_uah')?'amount_uah':'amount';
    $d=_col_exists('transactions','created_at')?'created_at':(_col_exists('transactions','date')?'date':'ts');
    $c=_col_exists('transactions','currency')?'currency':"'UAH'";
    return db_exec("SELECT t.`$d` AS created_at, t.type, t.`$a` AS amt, $c AS ccy, t.card_id FROM transactions t JOIN cards c ON c.id=t.card_id JOIN buyers b ON b.id=c.buyer_id WHERE b.team_id=? ORDER BY t.`$d` DESC LIMIT $limit", [$team_id])->fetchAll(PDO::FETCH_ASSOC);
  }
  return [];
}

/** Последние операции по работнику */
function drop_ops_last_by_drop(int $drop_id, int $limit=20): array {
  if (!_tbl_exists('drop_ops')) return [];
  return db_exec("SELECT created_at, type, amount_uah AS amt, 'UAH' AS ccy, card_id FROM drop_ops WHERE drop_id=? ORDER BY created_at DESC LIMIT $limit", [$drop_id])->fetchAll(PDO::FETCH_ASSOC);
}
