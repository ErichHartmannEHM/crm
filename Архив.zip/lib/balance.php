<?php
declare(strict_types=1);

require_once __DIR__.'/db.php';

/**
 * Находит колонку баланса в таблице cards.
 * Если подходящей колонки нет — создаёт `balance_uah` DECIMAL(14,2) NOT NULL DEFAULT 0.
 */
function cards_balance_column(): string {
    try {
        $cols = db_all("SHOW COLUMNS FROM `cards`");
        $have = [];
        foreach ($cols as $c) { $have[$c['Field']] = true; }
        foreach (['balance_uah','balance','current_balance','bal_uah'] as $cand) {
            if (!empty($have[$cand])) return $cand;
        }
        // если не нашли — создаём стандартную колонку
        try { db_exec("ALTER TABLE `cards` ADD COLUMN `balance_uah` DECIMAL(14,2) NOT NULL DEFAULT 0"); } catch (Throwable $e) {}
        return 'balance_uah';
    } catch (Throwable $e) {
        return 'balance_uah';
    }
}

/**
 * Возвращает название числовой колонки суммы в payments.
 */
function payments_amount_column(): string {
    try {
        $cols = db_all("SHOW COLUMNS FROM `payments`");
        $have = [];
        foreach ($cols as $c) { $have[$c['Field']] = true; }
        if (!empty($have['amount_uah'])) return 'amount_uah';
        if (!empty($have['amount'])) return 'amount';
        if (!empty($have['sum_uah'])) return 'sum_uah';
        if (!empty($have['sum'])) return 'sum';
    } catch (Throwable $e) {}
    return 'amount_uah';
}

/**
 * Пересчитать баланс по одной карте.
 * NEW_BAL = Σ(topup) − Σ(debit) + Σ(hold) по не-void операциям.
 */
function balance_recalc_for_card(int $card_id): void {
    $balCol = cards_balance_column();
    $amtCol = payments_amount_column();
    $hasVoid = false;
    try {
        $hasVoid = (int)db_col("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='payments' AND COLUMN_NAME='is_void'") > 0;
    } catch (Throwable $e) {}

    $voidCond = $hasVoid ? " AND IFNULL(p.is_void,0)=0" : "";
    $sql = "
        UPDATE cards c
        JOIN (
            SELECT
              p.card_id AS id,
              ROUND(
                COALESCE(SUM(CASE WHEN p.type='topup' THEN p.`$amtCol` END),0)
              - COALESCE(SUM(CASE WHEN p.type='debit' THEN p.`$amtCol` END),0)
              + COALESCE(SUM(CASE WHEN p.type='hold'  THEN p.`$amtCol` END),0)
              , 2) AS new_balance
            FROM payments p
            WHERE p.card_id=? $voidCond
            GROUP BY p.card_id
        ) x ON x.id = c.id
        SET c.`$balCol` = COALESCE(x.new_balance, 0)
    ";
    db_exec($sql, [$card_id]);
}

/**
 * Пересчитать балансы всех карт.
 * NEW_BAL = Σ(topup) − Σ(debit) + Σ(hold) по не-void операциям.
 * Возвращает число обновлённых карт.
 */
function balance_recalc_for_all(): int {
    $balCol = cards_balance_column();
    $amtCol = payments_amount_column();
    $hasVoid = false;
    try {
        $hasVoid = (int)db_col("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='payments' AND COLUMN_NAME='is_void'") > 0;
    } catch (Throwable $e) {}
    $voidCond = $hasVoid ? " AND IFNULL(p.is_void,0)=0" : "";

    $sql = "
        UPDATE cards c
        JOIN (
            SELECT
              p.card_id AS id,
              ROUND(
                COALESCE(SUM(CASE WHEN p.type='topup' THEN p.`$amtCol` END),0)
              - COALESCE(SUM(CASE WHEN p.type='debit' THEN p.`$amtCol` END),0)
              + COALESCE(SUM(CASE WHEN p.type='hold'  THEN p.`$amtCol` END),0)
              , 2) AS new_balance
            FROM payments p
            WHERE 1=1 $voidCond
            GROUP BY p.card_id
        ) x ON x.id = c.id
        SET c.`$balCol` = COALESCE(x.new_balance, 0)
    ";
    try {
        $stmt = db_exec($sql, []);
        return (int)$stmt->rowCount();
    } catch (Throwable $e) {
        return 0;
    }
}
