<?php
declare(strict_types=1);

require_once __DIR__.'/db.php';

function drop_by_chat($chat_id): ?array {
  try {
    $r = db_exec("SELECT * FROM drops WHERE IFNULL(is_active,1)=1 AND telegram_chat_id=? LIMIT 1", [$chat_id])->fetch(PDO::FETCH_ASSOC);
    return $r ?: null;
  } catch (Throwable $e) { return null; }
}

function drop_bind_chat(int $drop_id, $chat_id): bool {
  try {
    db_exec("UPDATE drops SET telegram_chat_id=? WHERE id=?", [$chat_id, $drop_id]);
    return true;
  } catch (Throwable $e) { return false; }
}

/** Карты, к которым работник имеет доступ */
function drop_cards(int $drop_id): array {
  try {
    return db_exec("
      SELECT c.*
      FROM drop_cards dc
      JOIN cards c ON c.id=dc.card_id
      WHERE dc.drop_id=?
      ORDER BY c.id DESC", [$drop_id])->fetchAll(PDO::FETCH_ASSOC);
  } catch (Throwable $e) { return []; }
}

function drop_can_use_card(int $drop_id, int $card_id): bool {
  try {
    return (int)db_exec("SELECT COUNT(*) FROM drop_cards WHERE drop_id=? AND card_id=?", [$drop_id,$card_id])->fetchColumn() > 0;
  } catch (Throwable $e) { return false; }
}
