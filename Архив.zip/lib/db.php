<?php
declare(strict_types=1);

/**
 * Minimal DB layer with proper typed parameter binding.
 * - Converts PHP null to PDO::PARAM_NULL
 * - Uses INT binding for integers
 * - String otherwise
 * 
 * Tries common config paths:
 *   /config.php         -> returns array like ['db'=>[...]]
 *   /config/app.php     -> same
 *   /config/config.php  -> same
 */

function app_config(): array {
    static $cfg;
    if ($cfg !== null) return $cfg;

    $candidates = [
        __DIR__ . '/../config.php',
        __DIR__ . '/../config/app.php',
        __DIR__ . '/../config/config.php',
    ];

    foreach ($candidates as $p) {
        if (is_file($p)) {
            $cfg = require $p;
            if (!is_array($cfg)) {
                throw new RuntimeException('Config file must return array: ' . $p);
            }
            return $cfg;
        }
    }
    throw new RuntimeException('Config file not found in expected locations.');
}

function db(): PDO {
    static $pdo;
    if ($pdo instanceof PDO) return $pdo;

    $cfg = app_config();
    if (!isset($cfg['db'])) {
        throw new RuntimeException('DB config section not found.');
    }
    $c = $cfg['db'];
    $host = $c['host'] ?? 'localhost';
    $port = (int)($c['port'] ?? 3306);
    $name = $c['name'] ?? '';
    $user = $c['user'] ?? '';
    $pass = $c['pass'] ?? '';
    $charset = $c['charset'] ?? 'utf8mb4';

    $dsn = sprintf('mysql:host=%s;port=%d;dbname=%s;charset=%s', $host, $port, $name, $charset);
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];

    $pdo = new PDO($dsn, $user, $pass, $options);
    return $pdo;
}

function _db_bind_value(PDOStatement $stmt, $key, $value): void {
    // normalize key to named/positional placeholder
    if (is_int($key)) {
        // positional placeholders are 1-based in bindValue
        $paramName = $key + 1;
    } else {
        $paramName = str_starts_with($key, ':') ? $key : ':' . $key;
    }

    if (is_null($value)) {
        $stmt->bindValue($paramName, null, PDO::PARAM_NULL);
    } elseif (is_int($value)) {
        $stmt->bindValue($paramName, $value, PDO::PARAM_INT);
    } else {
        $stmt->bindValue($paramName, (string)$value, PDO::PARAM_STR);
    }
}

function db_exec(string $sql, array $params = []): PDOStatement {
    $stmt = db()->prepare($sql);
    if ($params) {
        foreach ($params as $k => $v) {
            _db_bind_value($stmt, $k, $v);
        }
        $stmt->execute();
    } else {
        $stmt->execute();
    }
    return $stmt;
}

function db_row(string $sql, array $params = []): ?array {
    $stmt = db_exec($sql, $params);
    $row = $stmt->fetch();
    return $row === false ? null : $row;
}

function db_all(string $sql, array $params = []): array {
    return db_exec($sql, $params)->fetchAll();
}

function db_col(string $sql, array $params = []) {
    return db_exec($sql, $params)->fetchColumn();
}
