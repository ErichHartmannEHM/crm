<?php
declare(strict_types=1);
require_once __DIR__ . '/db.php';

/**
 * Simple key-value settings store.
 * Table: settings(k VARCHAR(128) PRIMARY KEY, val TEXT, updated_at DATETIME)
 */
function settings_bootstrap(): void {
    try {
        db_exec("CREATE TABLE IF NOT EXISTS `settings`(
            `k` VARCHAR(128) NOT NULL PRIMARY KEY,
            `val` TEXT NULL,
            `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {}
}
settings_bootstrap();

function setting_get(string $key, $default = null) {
    try {
        $row = db_row("SELECT `val` FROM `settings` WHERE `k` = ?", [$key]);
        if (!$row) return $default;
        $v = $row['val'];
        if ($v === null) return $default;
        // JSON decode if looks like JSON
        $trim = ltrim((string)$v);
        if ($trim !== '' && ($trim[0] === '{' || $trim[0] === '[' || $trim[0] === '"')) {
            $j = json_decode($v, true);
            if (json_last_error() === JSON_ERROR_NONE) return $j;
        }
        return $v;
    } catch (Throwable $e) {
        return $default;
    }
}

function setting_set(string $key, $value): void {
    try {
        if (is_array($value) || is_object($value)) {
            $value = json_encode($value, JSON_UNESCAPED_UNICODE);
        }
        db_exec("INSERT INTO `settings`(`k`,`val`,`updated_at`) VALUES(?,?,NOW())
                 ON DUPLICATE KEY UPDATE `val`=VALUES(`val`), `updated_at`=VALUES(`updated_at`)", [$key, $value]);
    } catch (Throwable $e) {}
}
